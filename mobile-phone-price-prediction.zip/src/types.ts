export enum PriceCategory {
  Budget = 0,
  MidRange = 1,
  UpperMidRange = 2,
  Premium = 3,
}

export const PRICE_CATEGORY_LABELS: Record<PriceCategory, string> = {
  [PriceCategory.Budget]: 'Budget',
  [PriceCategory.MidRange]: 'Mid-Range',
  [PriceCategory.UpperMidRange]: 'Upper Mid-Range',
  [PriceCategory.Premium]: 'Premium',
};

export const PRICE_CATEGORY_COLORS: Record<PriceCategory, { bg: string; text: string; border: string; bar: string }> = {
  [PriceCategory.Budget]: { bg: 'bg-emerald-50', text: 'text-emerald-700', border: 'border-emerald-200', bar: '#10b981' },
  [PriceCategory.MidRange]: { bg: 'bg-blue-50', text: 'text-blue-700', border: 'border-blue-200', bar: '#3b82f6' },
  [PriceCategory.UpperMidRange]: { bg: 'bg-amber-50', text: 'text-amber-700', border: 'border-amber-200', bar: '#f59e0b' },
  [PriceCategory.Premium]: { bg: 'bg-purple-50', text: 'text-purple-700', border: 'border-purple-200', bar: '#8b5cf6' },
};

export interface RawMobileRecord {
  mobile_id: string | number;
  brand: string;
  model: string;
  ram: string | number;
  internal_storage: string | number;
  battery_capacity: string | number;
  screen_size: string | number;
  primary_camera: string | number;
  front_camera: string | number;
  processor_speed: string | number;
  processor_cores: string | number;
  five_g: string | number | boolean;
  dual_sim: string | number | boolean;
  fast_charging: string | number | boolean;
  price_category: string | number;
}

export interface MobilePhone {
  id: number;
  brand: string;
  model: string;
  ram: number; // GB
  internalStorage: number; // GB
  batteryCapacity: number; // mAh
  screenSize: number; // inches
  primaryCamera: number; // MP
  frontCamera: number; // MP
  processorSpeed: number; // GHz
  processorCores: number;
  fiveG: number; // 1 or 0
  dualSim: number; // 1 or 0
  fastCharging: number; // 1 or 0
  priceCategory: PriceCategory;

  // Engineered features
  memoryScore: number;
  cameraScore: number;
  processingScore: number;
  connectivityScore: number;
  hardwareFeatureCount: number;
}

export interface PredictionInput {
  brand?: string;
  ram: number;
  internalStorage: number;
  batteryCapacity: number;
  screenSize: number;
  primaryCamera: number;
  frontCamera: number;
  processorSpeed: number;
  processorCores: number;
  fiveG: number;
  dualSim: number;
  fastCharging: number;
}

export interface PredictionResult {
  predictedCategory: PriceCategory;
  categoryName: string;
  confidence: number;
  probabilities: Record<PriceCategory, number>;
  modelUsed: 'Decision Tree' | 'Random Forest';
  input: PredictionInput;
  timestamp: string;
}

export interface FeatureImportance {
  feature: string;
  label: string;
  importance: number;
  percentage: number;
}

export interface ConfusionMatrixRow {
  actual: PriceCategory;
  actualLabel: string;
  predicted: Record<PriceCategory, number>;
  total: number;
}

export interface ClassMetrics {
  category: PriceCategory;
  label: string;
  precision: number;
  recall: number;
  f1: number;
  support: number;
}

export interface ModelMetrics {
  name: 'Decision Tree' | 'Random Forest';
  accuracy: number;
  precisionMacro: number;
  recallMacro: number;
  f1Macro: number;
  precisionWeighted: number;
  recallWeighted: number;
  f1Weighted: number;
  classMetrics: ClassMetrics[];
  confusionMatrix: ConfusionMatrixRow[];
  featureImportances: FeatureImportance[];
}

export interface TrainingResult {
  decisionTree: ModelMetrics;
  randomForest: ModelMetrics;
  bestModel: 'Decision Tree' | 'Random Forest';
  trainCount: number;
  testCount: number;
  featureCount: number;
  features: string[];
  trainedAt: string;
}

export interface DatasetStats {
  totalPhones: number;
  totalCategories: number;
  avgRam: number;
  avgStorage: number;
  avgBattery: number;
  avgScreenSize: number;
  avgPrimaryCamera: number;
  avgFrontCamera: number;
  avgProcessorSpeed: number;
  fiveGPercent: number;
  fiveGCount: number;
  fastChargingPercent: number;
  fastChargingCount: number;
  mostCommonCategory: string;
  categoryCounts: Record<PriceCategory, number>;
  brands: string[];
}
