import Papa from 'papaparse';
import { MobilePhone, RawMobileRecord, DatasetStats, PriceCategory, PRICE_CATEGORY_LABELS } from '../types';
import { preprocessDataset } from '../ml/preprocessing';

export interface DatasetLoadResult {
  phones: MobilePhone[];
  stats: DatasetStats;
  duplicatesRemoved: number;
  imputedValues: number;
}

export async function loadMobileDataset(): Promise<DatasetLoadResult> {
  const response = await fetch('/data/mobile_phones.csv');
  if (!response.ok) {
    throw new Error(`Failed to load dataset: ${response.status} ${response.statusText}`);
  }

  const csvText = await response.text();
  if (!csvText || csvText.trim().length === 0) {
    throw new Error('Dataset file is empty.');
  }

  return new Promise((resolve, reject) => {
    Papa.parse<RawMobileRecord>(csvText, {
      header: true,
      skipEmptyLines: true,
      dynamicTyping: false,
      complete: (results) => {
        try {
          if (!results.data || results.data.length === 0) {
            reject(new Error('Parsed CSV contains no rows.'));
            return;
          }

          // Validate required headers
          const firstRow = results.data[0];
          const requiredCols = ['ram', 'internal_storage', 'battery_capacity', 'screen_size', 'price_category'];
          for (const col of requiredCols) {
            if (!(col in firstRow)) {
              reject(new Error(`Missing required CSV column: '${col}'`));
              return;
            }
          }

          const { data: phones, droppedDuplicates, imputedValues } = preprocessDataset(results.data);

          if (phones.length === 0) {
            reject(new Error('No valid mobile records found after preprocessing.'));
            return;
          }

          const stats = calculateDatasetStats(phones);
          resolve({
            phones,
            stats,
            duplicatesRemoved: droppedDuplicates,
            imputedValues,
          });
        } catch (err) {
          reject(err);
        }
      },
      error: (error: Error) => {
        reject(new Error(`CSV Parsing error: ${error.message}`));
      },
    });
  });
}

export function calculateDatasetStats(phones: MobilePhone[]): DatasetStats {
  const total = phones.length;
  if (total === 0) {
    return {
      totalPhones: 0,
      totalCategories: 4,
      avgRam: 0,
      avgStorage: 0,
      avgBattery: 0,
      avgScreenSize: 0,
      avgPrimaryCamera: 0,
      avgFrontCamera: 0,
      avgProcessorSpeed: 0,
      fiveGPercent: 0,
      fiveGCount: 0,
      fastChargingPercent: 0,
      fastChargingCount: 0,
      mostCommonCategory: 'None',
      categoryCounts: {
        [PriceCategory.Budget]: 0,
        [PriceCategory.MidRange]: 0,
        [PriceCategory.UpperMidRange]: 0,
        [PriceCategory.Premium]: 0,
      },
      brands: [],
    };
  }

  let sumRam = 0;
  let sumStorage = 0;
  let sumBattery = 0;
  let sumScreen = 0;
  let sumPrimaryCam = 0;
  let sumFrontCam = 0;
  let sumProcSpeed = 0;
  let fiveGCount = 0;
  let fastChargingCount = 0;

  const categoryCounts: Record<PriceCategory, number> = {
    [PriceCategory.Budget]: 0,
    [PriceCategory.MidRange]: 0,
    [PriceCategory.UpperMidRange]: 0,
    [PriceCategory.Premium]: 0,
  };

  const brandSet = new Set<string>();

  for (const p of phones) {
    sumRam += p.ram;
    sumStorage += p.internalStorage;
    sumBattery += p.batteryCapacity;
    sumScreen += p.screenSize;
    sumPrimaryCam += p.primaryCamera;
    sumFrontCam += p.frontCamera;
    sumProcSpeed += p.processorSpeed;

    if (p.fiveG === 1) fiveGCount++;
    if (p.fastCharging === 1) fastChargingCount++;

    categoryCounts[p.priceCategory] = (categoryCounts[p.priceCategory] || 0) + 1;
    if (p.brand) brandSet.add(p.brand);
  }

  let mostCommonCat = PriceCategory.Budget;
  let maxCount = -1;
  for (const c of [PriceCategory.Budget, PriceCategory.MidRange, PriceCategory.UpperMidRange, PriceCategory.Premium]) {
    if (categoryCounts[c] > maxCount) {
      maxCount = categoryCounts[c];
      mostCommonCat = c;
    }
  }

  return {
    totalPhones: total,
    totalCategories: Object.keys(categoryCounts).length,
    avgRam: Number((sumRam / total).toFixed(1)),
    avgStorage: Number((sumStorage / total).toFixed(0)),
    avgBattery: Number((sumBattery / total).toFixed(0)),
    avgScreenSize: Number((sumScreen / total).toFixed(2)),
    avgPrimaryCamera: Number((sumPrimaryCam / total).toFixed(1)),
    avgFrontCamera: Number((sumFrontCam / total).toFixed(1)),
    avgProcessorSpeed: Number((sumProcSpeed / total).toFixed(2)),
    fiveGPercent: Number(((fiveGCount / total) * 100).toFixed(1)),
    fiveGCount,
    fastChargingPercent: Number(((fastChargingCount / total) * 100).toFixed(1)),
    fastChargingCount,
    mostCommonCategory: PRICE_CATEGORY_LABELS[mostCommonCat],
    categoryCounts,
    brands: Array.from(brandSet).sort(),
  };
}
