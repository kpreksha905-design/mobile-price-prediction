import React from 'react';
import {
  DatasetStats,
  TrainingResult,
  PriceCategory,
  PRICE_CATEGORY_LABELS,
  PRICE_CATEGORY_COLORS,
} from '../types';
import { CategorySpecAggregate } from '../utils/mobileAnalysis';
import { StatCard } from '../components/StatCard';
import { ChartCard } from '../components/ChartCard';
import { FeatureImportanceChart } from '../components/FeatureImportanceChart';
import {
  Smartphone,
  Layers,
  HardDrive,
  BatteryCharging,
  Cpu,
  Tv,
  Award,
  BarChart2,
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Cell,
  PieChart,
  Pie,
} from 'recharts';

interface DashboardProps {
  stats: DatasetStats;
  categoryAggregates: CategorySpecAggregate[];
  trainingResult?: TrainingResult;
  onNavigateToPredictor: () => void;
}

export const Dashboard: React.FC<DashboardProps> = ({
  stats,
  categoryAggregates,
  trainingResult,
  onNavigateToPredictor,
}) => {
  const categoryDistributionData = [
    PriceCategory.Budget,
    PriceCategory.MidRange,
    PriceCategory.UpperMidRange,
    PriceCategory.Premium,
  ].map(cat => ({
    name: PRICE_CATEGORY_LABELS[cat],
    count: stats.categoryCounts[cat] || 0,
    color: PRICE_CATEGORY_COLORS[cat].bar,
  }));

  const ramData = categoryAggregates.map(a => ({
    category: a.categoryLabel,
    avgRam: a.avgRam,
    color: a.color,
  }));

  const storageData = categoryAggregates.map(a => ({
    category: a.categoryLabel,
    avgStorage: a.avgStorage,
    color: a.color,
  }));

  const batteryData = categoryAggregates.map(a => ({
    category: a.categoryLabel,
    avgBattery: a.avgBattery,
    color: a.color,
  }));

  const screenData = categoryAggregates.map(a => ({
    category: a.categoryLabel,
    avgScreen: a.avgScreenSize,
    color: a.color,
  }));

  const cameraData = categoryAggregates.map(a => ({
    category: a.categoryLabel,
    primaryCam: a.avgPrimaryCam,
    frontCam: a.avgFrontCam,
  }));

  const bestModelDisplay = trainingResult ? trainingResult.bestModel : 'Calculating...';

  return (
    <div className="space-y-6">
      {/* Welcome & Call-to-action banner */}
      <div className="bg-slate-900 rounded-2xl p-6 text-white flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-blue-400">
              Browser-Native Intelligence
            </span>
            <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 border border-slate-700">
              Zero-Server Architecture
            </span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black tracking-tight mt-1 text-white">
            Mobile Specification &amp; Price Category Intelligence
          </h2>
          <p className="text-xs text-slate-400 mt-1 max-w-2xl">
            Classification models trained directly on historical mobile phone specs. Predict device price tier and explore architectural trends.
          </p>
        </div>

        <button
          id="hero-predict-now-button"
          onClick={onNavigateToPredictor}
          className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 active:bg-blue-700 text-white font-bold text-xs shadow-xs transition-all shrink-0 cursor-pointer"
        >
          Predict New Phone &rarr;
        </button>
      </div>

      {/* 8 Statistic Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3.5 sm:gap-4">
        <StatCard
          id="stat-total-phones"
          title="Total Mobile Phones"
          value={stats.totalPhones}
          unit="devices"
          subtitle={`${stats.brands.length} distinct brands`}
          icon={<Smartphone className="w-4 h-4" />}
          accent="blue"
        />
        <StatCard
          id="stat-total-categories"
          title="Total Price Categories"
          value={stats.totalCategories}
          unit="tiers"
          subtitle="Budget to Premium"
          icon={<Layers className="w-4 h-4" />}
          accent="purple"
        />
        <StatCard
          id="stat-avg-ram"
          title="Average RAM"
          value={stats.avgRam}
          unit="GB"
          subtitle="Min: 2 GB | Max: 16 GB"
          icon={<Cpu className="w-4 h-4" />}
          accent="default"
        />
        <StatCard
          id="stat-avg-storage"
          title="Average Storage"
          value={stats.avgStorage}
          unit="GB"
          subtitle="32 GB to 512 GB"
          icon={<HardDrive className="w-4 h-4" />}
          accent="default"
        />
        <StatCard
          id="stat-avg-battery"
          title="Average Battery"
          value={stats.avgBattery}
          unit="mAh"
          subtitle={`${stats.fastChargingPercent}% fast charge`}
          icon={<BatteryCharging className="w-4 h-4" />}
          accent="emerald"
        />
        <StatCard
          id="stat-avg-screen"
          title="Average Screen Size"
          value={stats.avgScreenSize}
          unit="inches"
          subtitle="OLED &amp; LCD displays"
          icon={<Tv className="w-4 h-4" />}
          accent="default"
        />
        <StatCard
          id="stat-common-category"
          title="Most Common Tier"
          value={stats.mostCommonCategory}
          subtitle={`${stats.categoryCounts[stats.mostCommonCategory === 'Budget' ? 0 : stats.mostCommonCategory === 'Mid-Range' ? 1 : stats.mostCommonCategory === 'Upper Mid-Range' ? 2 : 3] || 0} devices in dataset`}
          icon={<BarChart2 className="w-4 h-4" />}
          accent="amber"
        />
        <StatCard
          id="stat-best-model"
          title="Best Performing Model"
          value={bestModelDisplay}
          subtitle={
            trainingResult
              ? `${(trainingResult[trainingResult.bestModel === 'Random Forest' ? 'randomForest' : 'decisionTree'].f1Weighted * 100).toFixed(1)}% test F1 score`
              : 'Training in progress...'
          }
          icon={<Award className="w-4 h-4" />}
          accent="purple"
        />
      </div>

      {/* Dashboard Charts Row 1 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Chart 1: Price Category Distribution */}
        <ChartCard
          id="chart-category-distribution"
          title="Price Category Distribution"
          subtitle="Number of phones in each price tier in the dataset"
          badge="Market Split"
        >
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={categoryDistributionData} margin={{ top: 15, right: 20, left: -10, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
              <XAxis dataKey="name" tick={{ fontSize: 11, fill: '#475569' }} />
              <YAxis allowDecimals={false} tick={{ fontSize: 11, fill: '#64748b' }} />
              <Tooltip
                formatter={(val: unknown) => [`${val} phones`, 'Count']}
                contentStyle={{ borderRadius: '12px', border: 'none', background: '#0f172a', color: '#fff', fontSize: '12px' }}
              />
              <Bar dataKey="count" radius={[6, 6, 0, 0]}>
                {categoryDistributionData.map(entry => (
                  <Cell key={`cell-${entry.name}`} fill={entry.color} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        {/* Chart 2: RAM by Price Category */}
        <ChartCard
          id="chart-ram-by-category"
          title="RAM by Price Category"
          subtitle="Average RAM capacity (GB) across classification segments"
          badge="Memory Scaling"
        >
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={ramData} margin={{ top: 15, right: 20, left: -10, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
              <XAxis dataKey="category" tick={{ fontSize: 11, fill: '#475569' }} />
              <YAxis unit=" GB" tick={{ fontSize: 11, fill: '#64748b' }} />
              <Tooltip
                formatter={(val: unknown) => [`${val} GB`, 'Average RAM']}
                contentStyle={{ borderRadius: '12px', border: 'none', background: '#0f172a', color: '#fff', fontSize: '12px' }}
              />
              <Bar dataKey="avgRam" radius={[6, 6, 0, 0]}>
                {ramData.map(entry => (
                  <Cell key={`cell-${entry.category}`} fill={entry.color} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      {/* Dashboard Charts Row 2 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Chart 3: Storage by Price Category */}
        <ChartCard
          id="chart-storage-by-category"
          title="Storage by Price Category"
          subtitle="Average internal flash storage (GB) across categories"
          badge="ROM Baseline"
        >
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={storageData} margin={{ top: 15, right: 20, left: -10, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
              <XAxis dataKey="category" tick={{ fontSize: 11, fill: '#475569' }} />
              <YAxis unit=" GB" tick={{ fontSize: 11, fill: '#64748b' }} />
              <Tooltip
                formatter={(val: unknown) => [`${val} GB`, 'Average Storage']}
                contentStyle={{ borderRadius: '12px', border: 'none', background: '#0f172a', color: '#fff', fontSize: '12px' }}
              />
              <Bar dataKey="avgStorage" radius={[6, 6, 0, 0]}>
                {storageData.map(entry => (
                  <Cell key={`cell-${entry.category}`} fill={entry.color} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        {/* Chart 4: Battery Capacity by Price Category */}
        <ChartCard
          id="chart-battery-by-category"
          title="Battery Capacity by Price Category"
          subtitle="Average battery capacity (mAh) across categories"
          badge="Endurance"
        >
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={batteryData} margin={{ top: 15, right: 20, left: 10, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
              <XAxis dataKey="category" tick={{ fontSize: 11, fill: '#475569' }} />
              <YAxis domain={['dataMin - 500', 'dataMax + 500']} unit=" mAh" tick={{ fontSize: 10, fill: '#64748b' }} />
              <Tooltip
                formatter={(val: unknown) => [`${val} mAh`, 'Average Battery']}
                contentStyle={{ borderRadius: '12px', border: 'none', background: '#0f172a', color: '#fff', fontSize: '12px' }}
              />
              <Bar dataKey="avgBattery" radius={[6, 6, 0, 0]}>
                {batteryData.map(entry => (
                  <Cell key={`cell-${entry.category}`} fill={entry.color} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      {/* Dashboard Charts Row 3 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Chart 5: Camera Resolution by Category */}
        <ChartCard
          id="chart-camera-by-category"
          title="Camera Resolution by Price Category"
          subtitle="Comparison of Primary vs Front Selfie Camera Megapixels"
          badge="Optics"
        >
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={cameraData} margin={{ top: 15, right: 20, left: -10, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
              <XAxis dataKey="category" tick={{ fontSize: 11, fill: '#475569' }} />
              <YAxis unit=" MP" tick={{ fontSize: 11, fill: '#64748b' }} />
              <Tooltip
                formatter={(val: unknown, name: unknown) => [
                  `${val} MP`,
                  name === 'primaryCam' ? 'Primary Camera' : 'Front Camera',
                ]}
                contentStyle={{ borderRadius: '12px', border: 'none', background: '#0f172a', color: '#fff', fontSize: '12px' }}
              />
              <Bar dataKey="primaryCam" name="primaryCam" fill="#2563eb" radius={[5, 5, 0, 0]} />
              <Bar dataKey="frontCam" name="frontCam" fill="#93c5fd" radius={[5, 5, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        {/* Chart 6: Screen Size by Price Category */}
        <ChartCard
          id="chart-screen-by-category"
          title="Screen Size by Price Category"
          subtitle="Average diagonal display size (inches) across tiers"
          badge="Form Factor"
        >
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={screenData} margin={{ top: 15, right: 20, left: -10, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
              <XAxis dataKey="category" tick={{ fontSize: 11, fill: '#475569' }} />
              <YAxis domain={[5.5, 7.2]} unit='"' tick={{ fontSize: 11, fill: '#64748b' }} />
              <Tooltip
                formatter={(val: unknown) => [`${val} inches`, 'Average Screen Size']}
                contentStyle={{ borderRadius: '12px', border: 'none', background: '#0f172a', color: '#fff', fontSize: '12px' }}
              />
              <Bar dataKey="avgScreen" radius={[6, 6, 0, 0]}>
                {screenData.map(entry => (
                  <Cell key={`cell-${entry.category}`} fill={entry.color} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      {/* Chart 7: ML-Derived Feature Importance */}
      {trainingResult && (
        <ChartCard
          id="chart-dashboard-feature-importance"
          title="ML-Derived Specification Importance Ranking"
          subtitle="Influence weights derived from the Random Forest ensemble classifier"
          badge="Random Forest ML"
          heightClass="h-80"
        >
          <FeatureImportanceChart
            features={trainingResult.randomForest.featureImportances}
            topN={8}
          />
        </ChartCard>
      )}
    </div>
  );
};
