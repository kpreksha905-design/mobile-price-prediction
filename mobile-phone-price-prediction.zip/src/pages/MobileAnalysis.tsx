import React, { useState } from 'react';
import {
  MobilePhone,
  DatasetStats,
  PriceCategory,
  PRICE_CATEGORY_LABELS,
  PRICE_CATEGORY_COLORS,
} from '../types';
import {
  CategorySpecAggregate,
  SpecificationDistribution,
} from '../utils/mobileAnalysis';
import { DynamicInsightItem } from '../utils/insights';
import { MobileTable } from '../components/MobileTable';
import { MobileDetailsModal } from '../components/MobileDetailsModal';
import { ChartCard } from '../components/ChartCard';
import {
  Lightbulb,
  Radio,
  Zap,
  TrendingUp,
  Cpu,
  Layers,
  Sparkles,
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Cell,
  PieChart,
  Pie,
} from 'recharts';

interface MobileAnalysisProps {
  phones: MobilePhone[];
  stats: DatasetStats;
  aggregates: CategorySpecAggregate[];
  distributions: SpecificationDistribution;
  insights: DynamicInsightItem[];
}

export const MobileAnalysis: React.FC<MobileAnalysisProps> = ({
  phones,
  stats,
  aggregates,
  distributions,
  insights,
}) => {
  const [selectedPhone, setSelectedPhone] = useState<MobilePhone | null>(null);

  // 5G Adoption pie chart data
  const fiveGData = [
    { name: '5G Enabled', value: stats.fiveGCount, color: '#2563eb' },
    { name: '4G LTE Only', value: stats.totalPhones - stats.fiveGCount, color: '#94a3b8' },
  ];

  // Fast charging pie chart data
  const fastChargingData = [
    { name: 'Fast Charging', value: stats.fastChargingCount, color: '#10b981' },
    { name: 'Standard Charging', value: stats.totalPhones - stats.fastChargingCount, color: '#cbd5e1' },
  ];

  return (
    <div className="space-y-8">
      {/* Page Header */}
      <div>
        <div className="flex items-center gap-2">
          <h2 className="text-xl sm:text-2xl font-black tracking-tight text-slate-900">
            Mobile Specification &amp; Market Analysis
          </h2>
          <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-slate-100 text-slate-700">
            Dataset Analytics
          </span>
        </div>
        <p className="text-xs text-slate-500 mt-1 max-w-3xl">
          Deep-dive analysis of hardware distributions across memory, processors, battery capacities, and camera optics across {stats.totalPhones} phones.
        </p>
      </div>

      {/* Dynamic Insights Grid */}
      <div>
        <div className="flex items-center gap-2 mb-3">
          <Lightbulb className="w-4 h-4 text-amber-500" />
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500">
            Automated Machine Intelligence Insights
          </h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
          {insights.map(item => (
            <div
              key={item.id}
              className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200/90 shadow-2xs hover:border-slate-300 transition-colors flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-2">
                  <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-slate-100 text-slate-600">
                    {item.category}
                  </span>
                  {item.badge && (
                    <span className="text-xs font-bold font-mono text-blue-600">
                      {item.badge}
                    </span>
                  )}
                </div>
                <h4 className="text-sm font-bold text-slate-900 leading-snug">
                  {item.title}
                </h4>
                <p className="text-xs text-slate-600 mt-1.5 leading-relaxed">
                  {item.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Hardware Distribution Charts Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* RAM Distribution */}
        <ChartCard
          id="chart-ram-distribution"
          title="RAM Distribution"
          subtitle="Frequency of RAM capacities (GB)"
          badge="Memory"
        >
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={distributions.ram} margin={{ top: 10, right: 10, left: -20, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
              <XAxis dataKey="value" tick={{ fontSize: 11, fill: '#475569' }} />
              <YAxis allowDecimals={false} tick={{ fontSize: 11, fill: '#64748b' }} />
              <Tooltip
                formatter={(v: unknown) => [`${v} phones`, 'Count']}
                contentStyle={{ borderRadius: '12px', border: 'none', background: '#0f172a', color: '#fff', fontSize: '12px' }}
              />
              <Bar dataKey="count" fill="#3b82f6" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        {/* Storage Distribution */}
        <ChartCard
          id="chart-storage-distribution"
          title="Storage Distribution"
          subtitle="Frequency of Internal Storage (GB)"
          badge="Flash ROM"
        >
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={distributions.storage} margin={{ top: 10, right: 10, left: -20, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
              <XAxis dataKey="value" tick={{ fontSize: 11, fill: '#475569' }} />
              <YAxis allowDecimals={false} tick={{ fontSize: 11, fill: '#64748b' }} />
              <Tooltip
                formatter={(v: unknown) => [`${v} phones`, 'Count']}
                contentStyle={{ borderRadius: '12px', border: 'none', background: '#0f172a', color: '#fff', fontSize: '12px' }}
              />
              <Bar dataKey="count" fill="#8b5cf6" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        {/* Battery Distribution */}
        <ChartCard
          id="chart-battery-distribution"
          title="Battery Distribution"
          subtitle="Frequency across capacity tiers"
          badge="mAh"
        >
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={distributions.battery} margin={{ top: 10, right: 10, left: -20, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
              <XAxis dataKey="range" tick={{ fontSize: 10, fill: '#475569' }} />
              <YAxis allowDecimals={false} tick={{ fontSize: 11, fill: '#64748b' }} />
              <Tooltip
                formatter={(v: unknown) => [`${v} phones`, 'Count']}
                contentStyle={{ borderRadius: '12px', border: 'none', background: '#0f172a', color: '#fff', fontSize: '12px' }}
              />
              <Bar dataKey="count" fill="#10b981" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        {/* Camera Distribution */}
        <ChartCard
          id="chart-camera-distribution"
          title="Main Camera Distribution"
          subtitle="Frequency of primary sensor resolutions"
          badge="Megapixels"
        >
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={distributions.camera} margin={{ top: 10, right: 10, left: -20, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
              <XAxis dataKey="range" tick={{ fontSize: 10, fill: '#475569' }} />
              <YAxis allowDecimals={false} tick={{ fontSize: 11, fill: '#64748b' }} />
              <Tooltip
                formatter={(v: unknown) => [`${v} phones`, 'Count']}
                contentStyle={{ borderRadius: '12px', border: 'none', background: '#0f172a', color: '#fff', fontSize: '12px' }}
              />
              <Bar dataKey="count" fill="#f59e0b" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        {/* 5G Adoption Rate */}
        <ChartCard
          id="chart-5g-adoption"
          title="5G Adoption Rate"
          subtitle={`${stats.fiveGPercent}% of dataset phones feature 5G`}
          badge="Connectivity"
        >
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={fiveGData}
                dataKey="value"
                nameKey="name"
                cx="50%"
                cy="50%"
                innerRadius={50}
                outerRadius={75}
                paddingAngle={4}
              >
                {fiveGData.map(entry => (
                  <Cell key={`cell-${entry.name}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip
                formatter={(v: unknown) => [`${v} phones`, 'Share']}
                contentStyle={{ borderRadius: '12px', border: 'none', background: '#0f172a', color: '#fff', fontSize: '12px' }}
              />
            </PieChart>
          </ResponsiveContainer>
        </ChartCard>

        {/* Fast Charging Adoption */}
        <ChartCard
          id="chart-charging-adoption"
          title="Fast Charging Adoption"
          subtitle={`${stats.fastChargingPercent}% support rapid charge`}
          badge="Power"
        >
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={fastChargingData}
                dataKey="value"
                nameKey="name"
                cx="50%"
                cy="50%"
                innerRadius={50}
                outerRadius={75}
                paddingAngle={4}
              >
                {fastChargingData.map(entry => (
                  <Cell key={`cell-${entry.name}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip
                formatter={(v: unknown) => [`${v} phones`, 'Share']}
                contentStyle={{ borderRadius: '12px', border: 'none', background: '#0f172a', color: '#fff', fontSize: '12px' }}
              />
            </PieChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      {/* Category-Wise Hardware Averages Benchmark Table */}
      <div className="bg-white rounded-2xl p-5 sm:p-6 border border-slate-200/90 shadow-2xs">
        <div className="mb-4">
          <h3 className="text-base font-bold text-slate-900 tracking-tight">
            Category-Wise Hardware Averages Matrix
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Cross-segment hardware comparison demonstrating clear hardware scaling between Budget and Premium price tiers.
          </p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50 text-slate-500 uppercase tracking-wider font-semibold">
                <th className="p-3 rounded-tl-xl">Price Tier</th>
                <th className="p-3 text-right">Devices</th>
                <th className="p-3 text-right">Avg RAM</th>
                <th className="p-3 text-right">Avg Storage</th>
                <th className="p-3 text-right">Avg Battery</th>
                <th className="p-3 text-right">Avg Screen</th>
                <th className="p-3 text-right">Avg Main Cam</th>
                <th className="p-3 text-right">Avg Clock</th>
                <th className="p-3 text-right rounded-tr-xl">5G Adoption</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {aggregates.map(row => (
                <tr key={row.category} className="hover:bg-slate-50/50">
                  <td className="p-3 font-bold text-slate-900 flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: row.color }} />
                    <span>{row.categoryLabel}</span>
                  </td>
                  <td className="p-3 text-right font-mono text-slate-700">{row.count}</td>
                  <td className="p-3 text-right font-mono font-bold text-blue-700">{row.avgRam} GB</td>
                  <td className="p-3 text-right font-mono text-slate-700">{row.avgStorage} GB</td>
                  <td className="p-3 text-right font-mono text-slate-700">{row.avgBattery} mAh</td>
                  <td className="p-3 text-right font-mono text-slate-700">{row.avgScreenSize}"</td>
                  <td className="p-3 text-right font-mono text-slate-700">{row.avgPrimaryCam} MP</td>
                  <td className="p-3 text-right font-mono text-slate-700">{row.avgProcessorSpeed} GHz</td>
                  <td className="p-3 text-right font-mono font-semibold text-emerald-600">{row.pct5G}%</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Mobile Explorer Section */}
      <div>
        <div className="mb-4">
          <h3 className="text-lg font-bold text-slate-900 tracking-tight">
            Mobile Phone Explorer &amp; Search Directory
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Filter, sort, and inspect individual hardware profiles across all {phones.length} devices in the dataset.
          </p>
        </div>

        <MobileTable
          phones={phones}
          brands={stats.brands}
          onSelectPhone={phone => setSelectedPhone(phone)}
        />
      </div>

      {/* Selected Phone Details Modal */}
      <MobileDetailsModal
        phone={selectedPhone}
        datasetStats={stats}
        onClose={() => setSelectedPhone(null)}
      />
    </div>
  );
};
