import React, { useState } from 'react';
import { TrainingResult } from '../types';
import { ModelMetricsTable } from '../components/ModelMetricsTable';
import { ConfusionMatrix } from '../components/ConfusionMatrix';
import { FeatureImportanceChart } from '../components/FeatureImportanceChart';
import { ChartCard } from '../components/ChartCard';
import { Award, Layers, Sparkles, CheckCircle2 } from 'lucide-react';

interface ModelPerformanceProps {
  trainingResult?: TrainingResult;
}

export const ModelPerformance: React.FC<ModelPerformanceProps> = ({
  trainingResult,
}) => {
  const [activeMatrixModel, setActiveMatrixModel] = useState<'Random Forest' | 'Decision Tree'>('Random Forest');

  if (!trainingResult) {
    return (
      <div className="p-12 text-center bg-white rounded-2xl border border-slate-200">
        <p className="text-sm font-semibold text-slate-700">
          Training Machine Learning Models...
        </p>
      </div>
    );
  }

  const { decisionTree, randomForest, bestModel } = trainingResult;
  const currentMatrix = activeMatrixModel === 'Random Forest' ? randomForest.confusionMatrix : decisionTree.confusionMatrix;

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2">
          <h2 className="text-xl sm:text-2xl font-black tracking-tight text-slate-900">
            Model Evaluation &amp; Performance Metrics
          </h2>
          <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">
            20% Stratified Test Partition
          </span>
        </div>
        <p className="text-xs text-slate-500 mt-1 max-w-3xl">
          Comprehensive classification metrics, multiclass confusion matrix, and feature importance rankings computed from genuine test predictions.
        </p>
      </div>

      {/* Model Performance Comparison Component */}
      <ModelMetricsTable
        decisionTree={decisionTree}
        randomForest={randomForest}
        bestModel={bestModel}
      />

      {/* Confusion Matrix Section */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-base font-bold text-slate-900 tracking-tight">
              Test-Set Confusion Matrix
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Select which classifier model&apos;s multiclass confusion matrix to inspect.
            </p>
          </div>

          {/* Model Toggle for Matrix */}
          <div className="flex items-center gap-2 bg-slate-100 p-1 rounded-xl shrink-0">
            <button
              onClick={() => setActiveMatrixModel('Random Forest')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                activeMatrixModel === 'Random Forest'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Random Forest {bestModel === 'Random Forest' ? '★' : ''}
            </button>
            <button
              onClick={() => setActiveMatrixModel('Decision Tree')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                activeMatrixModel === 'Decision Tree'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Decision Tree {bestModel === 'Decision Tree' ? '★' : ''}
            </button>
          </div>
        </div>

        <ConfusionMatrix
          id="active-confusion-matrix"
          matrix={currentMatrix}
          modelName={activeMatrixModel}
        />
      </div>

      {/* Feature Importance Section */}
      <div className="space-y-4">
        <div>
          <h3 className="text-base font-bold text-slate-900 tracking-tight">
            Random Forest Feature Importance Analysis
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Gini impurity reduction weights calculated across all decision trees in the trained ensemble.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Chart */}
          <div className="lg:col-span-8">
            <ChartCard
              id="chart-model-feature-importance"
              title="Specification Influence Ranking"
              subtitle="Percentage contribution to category split decisions"
              badge="Ensemble Weights"
              heightClass="h-96"
            >
              <FeatureImportanceChart
                features={randomForest.featureImportances}
                topN={12}
              />
            </ChartCard>
          </div>

          {/* Table Breakdown */}
          <div className="lg:col-span-4 bg-white rounded-2xl p-5 border border-slate-200/90 shadow-2xs flex flex-col justify-between">
            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-3">
                Feature Weights Breakdown
              </h4>
              <div className="overflow-y-auto max-h-80 space-y-2 pr-1 text-xs">
                {randomForest.featureImportances.map((f, i) => (
                  <div
                    key={f.feature}
                    className="p-2.5 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-between"
                  >
                    <div className="flex items-center gap-2 truncate">
                      <span className="text-[10px] font-mono text-slate-400 w-4">
                        #{i + 1}
                      </span>
                      <span className="font-semibold text-slate-800 truncate">
                        {f.label}
                      </span>
                    </div>
                    <span className="font-mono font-bold text-blue-600 shrink-0">
                      {f.percentage}%
                    </span>
                  </div>
                ))}
              </div>
            </div>

            <div className="pt-3 mt-3 border-t border-slate-100 text-[11px] text-slate-400">
              * Higher percentage indicates stronger predictive discrimination when splitting categories.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
