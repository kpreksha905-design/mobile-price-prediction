import React, { useState } from 'react';
import { PredictionInput, PredictionResult } from '../types';
import { PricePredictionForm } from '../components/PricePredictionForm';
import { PredictionResultCard } from '../components/PredictionResultCard';
import { Sparkles, History, Cpu } from 'lucide-react';

interface PricePredictorProps {
  onPredict: (input: PredictionInput, model: 'Decision Tree' | 'Random Forest') => PredictionResult;
  isReady: boolean;
  bestModelName: 'Decision Tree' | 'Random Forest';
  lastPrediction: PredictionResult | null;
}

export const PricePredictor: React.FC<PricePredictorProps> = ({
  onPredict,
  isReady,
  bestModelName,
  lastPrediction,
}) => {
  const [history, setHistory] = useState<PredictionResult[]>([]);

  const handlePredict = (input: PredictionInput, modelType: 'Decision Tree' | 'Random Forest') => {
    const result = onPredict(input, modelType);
    setHistory(prev => [result, ...prev.slice(0, 4)]);
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div>
        <div className="flex items-center gap-2">
          <h2 className="text-xl sm:text-2xl font-black tracking-tight text-slate-900">
            Hardware Price Tier Predictor
          </h2>
          <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-blue-50 text-blue-700 border border-blue-200">
            In-Browser Classifier
          </span>
        </div>
        <p className="text-xs text-slate-500 mt-1 max-w-3xl">
          Enter mobile hardware specifications to predict the expected market price tier. The model evaluates features including RAM, storage, battery capacity, camera optics, processor speed, and connectivity.
        </p>
      </div>

      {/* Grid: Form & Result */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left column: Form (7 cols on lg) */}
        <div className="lg:col-span-7 space-y-6">
          <PricePredictionForm
            onPredict={handlePredict}
            isTraining={!isReady}
            bestModelName={bestModelName}
          />
        </div>

        {/* Right column: Results & History (5 cols on lg) */}
        <div className="lg:col-span-5 space-y-6">
          {lastPrediction ? (
            <PredictionResultCard
              id="latest-prediction-result"
              result={lastPrediction}
            />
          ) : (
            <div className="bg-white rounded-2xl p-8 border border-slate-200/90 shadow-2xs text-center flex flex-col items-center justify-center min-h-[380px]">
              <div className="w-14 h-14 rounded-2xl bg-blue-50 flex items-center justify-center text-blue-600 mb-4">
                <Cpu className="w-7 h-7" />
              </div>
              <h3 className="text-base font-bold text-slate-900">
                Awaiting Hardware Input
              </h3>
              <p className="text-xs text-slate-500 mt-1.5 max-w-xs">
                Select one of the quick presets on the left or customize specifications, then click &ldquo;Predict Price Category&rdquo;.
              </p>
              <div className="mt-4 pt-4 border-t border-slate-100 flex items-center gap-2 text-[11px] text-slate-400">
                <Sparkles className="w-3.5 h-3.5 text-blue-500" />
                <span>Zero latency &bull; 100% private in-browser compute</span>
              </div>
            </div>
          )}

          {/* Session History */}
          {history.length > 1 && (
            <div className="bg-white rounded-2xl p-5 border border-slate-200/90 shadow-2xs">
              <div className="flex items-center gap-2 mb-3 text-xs font-bold text-slate-700 uppercase tracking-wider">
                <History className="w-4 h-4 text-slate-500" />
                <span>Session Prediction History</span>
              </div>

              <div className="space-y-2">
                {history.slice(1).map((item, idx) => (
                  <div
                    key={idx}
                    className="p-3 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-between text-xs"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-800">
                          {item.categoryName}
                        </span>
                        <span className="text-[10px] text-slate-400">
                          ({item.modelUsed})
                        </span>
                      </div>
                      <span className="text-[10px] text-slate-500">
                        {item.input.ram}GB / {item.input.internalStorage}GB &bull; {item.input.batteryCapacity}mAh
                      </span>
                    </div>

                    <span className="font-mono font-bold text-slate-700 bg-white px-2 py-1 rounded-md border border-slate-200 text-[11px]">
                      {(item.confidence * 100).toFixed(0)}% conf
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
