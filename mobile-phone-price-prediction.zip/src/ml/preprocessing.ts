import { RawMobileRecord, MobilePhone, PriceCategory } from '../types';
import { calculateEngineeredFeatures } from './featureEngineering';

function parseBinary(val: unknown): number {
  if (val === undefined || val === null) return 0;
  const s = String(val).trim().toLowerCase();
  if (s === 'yes' || s === '1' || s === 'true') return 1;
  return 0;
}

function calculateMedian(numbers: number[]): number {
  if (numbers.length === 0) return 0;
  const sorted = [...numbers].sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  return sorted.length % 2 !== 0 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2;
}

export function preprocessDataset(rawRecords: RawMobileRecord[]): {
  data: MobilePhone[];
  droppedDuplicates: number;
  imputedValues: number;
} {
  let droppedDuplicates = 0;
  let imputedValues = 0;

  // Step 1: Remove completely empty rows
  const nonEmpty = rawRecords.filter(row => {
    return row && (row.brand || row.model || row.ram !== undefined);
  });

  // Step 2: Remove duplicate records based on brand, model, and ram/storage
  const seenKeys = new Set<string>();
  const uniqueRows: RawMobileRecord[] = [];

  for (const row of nonEmpty) {
    const key = `${String(row.brand || '').trim().toLowerCase()}-${String(row.model || '').trim().toLowerCase()}-${row.ram}-${row.internal_storage}`;
    if (seenKeys.has(key)) {
      droppedDuplicates++;
      continue;
    }
    seenKeys.add(key);
    uniqueRows.push(row);
  }

  // Step 3: Compute medians for numeric imputation
  const ramValues: number[] = [];
  const storageValues: number[] = [];
  const batteryValues: number[] = [];
  const screenValues: number[] = [];
  const primaryCamValues: number[] = [];
  const frontCamValues: number[] = [];
  const procSpeedValues: number[] = [];
  const procCoresValues: number[] = [];

  for (const row of uniqueRows) {
    const r = parseFloat(String(row.ram));
    if (!isNaN(r)) ramValues.push(r);

    const s = parseFloat(String(row.internal_storage));
    if (!isNaN(s)) storageValues.push(s);

    const b = parseFloat(String(row.battery_capacity));
    if (!isNaN(b)) batteryValues.push(b);

    const sc = parseFloat(String(row.screen_size));
    if (!isNaN(sc)) screenValues.push(sc);

    const pc = parseFloat(String(row.primary_camera));
    if (!isNaN(pc)) primaryCamValues.push(pc);

    const fc = parseFloat(String(row.front_camera));
    if (!isNaN(fc)) frontCamValues.push(fc);

    const ps = parseFloat(String(row.processor_speed));
    if (!isNaN(ps)) procSpeedValues.push(ps);

    const cor = parseFloat(String(row.processor_cores));
    if (!isNaN(cor)) procCoresValues.push(cor);
  }

  const medianRam = calculateMedian(ramValues) || 6;
  const medianStorage = calculateMedian(storageValues) || 128;
  const medianBattery = calculateMedian(batteryValues) || 5000;
  const medianScreen = calculateMedian(screenValues) || 6.67;
  const medianPrimaryCam = calculateMedian(primaryCamValues) || 50;
  const medianFrontCam = calculateMedian(frontCamValues) || 16;
  const medianProcSpeed = calculateMedian(procSpeedValues) || 2.4;
  const medianProcCores = calculateMedian(procCoresValues) || 8;

  // Step 4: Parse each record and build MobilePhone objects
  const processedPhones: MobilePhone[] = [];

  for (let i = 0; i < uniqueRows.length; i++) {
    const row = uniqueRows[i];

    // Check numericals with imputation fallback
    let ram = parseFloat(String(row.ram));
    if (isNaN(ram) || ram <= 0) {
      ram = medianRam;
      imputedValues++;
    }

    let internalStorage = parseFloat(String(row.internal_storage));
    if (isNaN(internalStorage) || internalStorage <= 0) {
      internalStorage = medianStorage;
      imputedValues++;
    }

    let batteryCapacity = parseFloat(String(row.battery_capacity));
    if (isNaN(batteryCapacity) || batteryCapacity <= 0) {
      batteryCapacity = medianBattery;
      imputedValues++;
    }

    let screenSize = parseFloat(String(row.screen_size));
    if (isNaN(screenSize) || screenSize <= 0) {
      screenSize = medianScreen;
      imputedValues++;
    }

    let primaryCamera = parseFloat(String(row.primary_camera));
    if (isNaN(primaryCamera) || primaryCamera <= 0) {
      primaryCamera = medianPrimaryCam;
      imputedValues++;
    }

    let frontCamera = parseFloat(String(row.front_camera));
    if (isNaN(frontCamera) || frontCamera <= 0) {
      frontCamera = medianFrontCam;
      imputedValues++;
    }

    let processorSpeed = parseFloat(String(row.processor_speed));
    if (isNaN(processorSpeed) || processorSpeed <= 0) {
      processorSpeed = medianProcSpeed;
      imputedValues++;
    }

    let processorCores = parseFloat(String(row.processor_cores));
    if (isNaN(processorCores) || processorCores <= 0) {
      processorCores = medianProcCores;
      imputedValues++;
    }

    const fiveG = parseBinary(row.five_g);
    const dualSim = parseBinary(row.dual_sim);
    const fastCharging = parseBinary(row.fast_charging);

    // Target category validation (0, 1, 2, 3)
    let cat = parseInt(String(row.price_category), 10);
    if (isNaN(cat) || cat < 0 || cat > 3) {
      // Map string labels if necessary
      const strCat = String(row.price_category || '').toLowerCase();
      if (strCat.includes('budget')) cat = PriceCategory.Budget;
      else if (strCat.includes('upper')) cat = PriceCategory.UpperMidRange;
      else if (strCat.includes('mid')) cat = PriceCategory.MidRange;
      else if (strCat.includes('prem')) cat = PriceCategory.Premium;
      else cat = PriceCategory.MidRange;
    }

    const engineered = calculateEngineeredFeatures({
      ram,
      internalStorage,
      primaryCamera,
      frontCamera,
      processorSpeed,
      processorCores,
      fiveG,
      dualSim,
      fastCharging,
    });

    processedPhones.push({
      id: Number(row.mobile_id) || i + 1,
      brand: String(row.brand || 'Unknown').trim(),
      model: String(row.model || 'Unknown Model').trim(),
      ram,
      internalStorage,
      batteryCapacity,
      screenSize,
      primaryCamera,
      frontCamera,
      processorSpeed,
      processorCores,
      fiveG,
      dualSim,
      fastCharging,
      priceCategory: cat as PriceCategory,
      ...engineered,
    });
  }

  return {
    data: processedPhones,
    droppedDuplicates,
    imputedValues,
  };
}
