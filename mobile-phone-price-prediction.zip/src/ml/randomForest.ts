import { PriceCategory } from '../types';
import { DecisionTreeClassifier } from './decisionTree';

export interface RandomForestOptions {
  nEstimators?: number;
  maxDepth?: number;
  minSamplesSplit?: number;
  minSamplesLeaf?: number;
}

export class RandomForestClassifier {
  trees: DecisionTreeClassifier[] = [];
  nEstimators: number;
  maxDepth: number;
  minSamplesSplit: number;
  minSamplesLeaf: number;
  featureImportances: number[] = [];
  classes: PriceCategory[] = [
    PriceCategory.Budget,
    PriceCategory.MidRange,
    PriceCategory.UpperMidRange,
    PriceCategory.Premium,
  ];

  constructor(options: RandomForestOptions = {}) {
    this.nEstimators = options.nEstimators ?? 16;
    this.maxDepth = options.maxDepth ?? 5;
    this.minSamplesSplit = options.minSamplesSplit ?? 3;
    this.minSamplesLeaf = options.minSamplesLeaf ?? 2;
  }

  fit(X: number[][], y: PriceCategory[]): void {
    if (X.length === 0 || y.length === 0) return;
    const nSamples = X.length;
    const nFeatures = X[0].length;
    // Subsample features per split (standard sqrt(d) or min(d, max(4, round(sqrt(d)*1.5))))
    const maxFeatures = Math.max(3, Math.min(nFeatures, Math.round(Math.sqrt(nFeatures) * 1.5)));

    this.trees = [];
    const aggregatedImportances = new Array(nFeatures).fill(0);

    for (let t = 0; t < this.nEstimators; t++) {
      // Bootstrap sampling with replacement
      const bootIndices: number[] = [];
      for (let i = 0; i < nSamples; i++) {
        const randIdx = Math.floor(Math.random() * nSamples);
        bootIndices.push(randIdx);
      }

      const bootX = bootIndices.map(idx => X[idx]);
      const bootY = bootIndices.map(idx => y[idx]);

      const tree = new DecisionTreeClassifier({
        maxDepth: this.maxDepth,
        minSamplesSplit: this.minSamplesSplit,
        minSamplesLeaf: this.minSamplesLeaf,
        maxFeatures,
      });

      tree.fit(bootX, bootY);
      this.trees.push(tree);

      // Accumulate importances
      for (let f = 0; f < nFeatures; f++) {
        aggregatedImportances[f] += tree.featureImportances[f] || 0;
      }
    }

    // Average and normalize importances
    const totalImp = aggregatedImportances.reduce((a, b) => a + b, 0);
    this.featureImportances = totalImp > 0
      ? aggregatedImportances.map(v => v / totalImp)
      : new Array(nFeatures).fill(1 / nFeatures);
  }

  predictProbabilities(x: number[]): Record<PriceCategory, number> {
    const avgProbs: Record<PriceCategory, number> = {
      [PriceCategory.Budget]: 0,
      [PriceCategory.MidRange]: 0,
      [PriceCategory.UpperMidRange]: 0,
      [PriceCategory.Premium]: 0,
    };

    if (this.trees.length === 0) {
      return {
        [PriceCategory.Budget]: 0.25,
        [PriceCategory.MidRange]: 0.25,
        [PriceCategory.UpperMidRange]: 0.25,
        [PriceCategory.Premium]: 0.25,
      };
    }

    for (const tree of this.trees) {
      const treeProbs = tree.predictProbabilities(x);
      for (const c of this.classes) {
        avgProbs[c] += treeProbs[c];
      }
    }

    for (const c of this.classes) {
      avgProbs[c] = avgProbs[c] / this.trees.length;
    }

    return avgProbs;
  }

  predict(x: number[]): PriceCategory {
    const probs = this.predictProbabilities(x);
    let bestClass = PriceCategory.Budget;
    let maxP = -1;
    for (const c of this.classes) {
      if (probs[c] > maxP) {
        maxP = probs[c];
        bestClass = c;
      }
    }
    return bestClass;
  }
}
