import { PredictionInput } from '../types';

export interface EngineeredFeatures {
  memoryScore: number;
  cameraScore: number;
  processingScore: number;
  connectivityScore: number;
  hardwareFeatureCount: number;
}

export const FEATURE_NAMES = [
  'ram',
  'internal_storage',
  'battery_capacity',
  'screen_size',
  'primary_camera',
  'front_camera',
  'processor_speed',
  'processor_cores',
  'five_g',
  'dual_sim',
  'fast_charging',
  'memory_score',
  'camera_score',
  'processing_score',
  'connectivity_score',
  'hardware_feature_count',
];

export const FEATURE_LABELS: Record<string, string> = {
  ram: 'RAM (GB)',
  internal_storage: 'Internal Storage (GB)',
  battery_capacity: 'Battery Capacity (mAh)',
  screen_size: 'Screen Size (in)',
  primary_camera: 'Primary Camera (MP)',
  front_camera: 'Front Camera (MP)',
  processor_speed: 'Processor Clock (GHz)',
  processor_cores: 'CPU Cores',
  five_g: '5G Connectivity',
  dual_sim: 'Dual SIM',
  fast_charging: 'Fast Charging',
  memory_score: 'Memory Capacity Score',
  camera_score: 'Camera Capability Score',
  processing_score: 'CPU Processing Index',
  connectivity_score: 'Connectivity Score',
  hardware_feature_count: 'Hardware Feature Count',
};

/**
 * Derives engineered features strictly from input hardware specifications without target leakage.
 */
export function calculateEngineeredFeatures(input: {
  ram: number;
  internalStorage: number;
  primaryCamera: number;
  frontCamera: number;
  processorSpeed: number;
  processorCores: number;
  fiveG: number;
  dualSim: number;
  fastCharging: number;
}): EngineeredFeatures {
  // Memory capacity score normalized across typical upper boundaries
  const memoryScore = Number(((input.ram / 16) * 0.5 + (input.internalStorage / 512) * 0.5).toFixed(4));

  // Camera score weighting primary and selfie resolution
  const cameraScore = Number(((input.primaryCamera / 200) * 0.65 + (input.frontCamera / 50) * 0.35).toFixed(4));

  // Processing power proxy: speed * cores
  const processingScore = Number((input.processorSpeed * input.processorCores).toFixed(2));

  // Connectivity score: 5G + Dual SIM
  const connectivityScore = input.fiveG + input.dualSim;

  // Hardware feature count: 5G + Dual SIM + Fast Charging
  const hardwareFeatureCount = input.fiveG + input.dualSim + input.fastCharging;

  return {
    memoryScore,
    cameraScore,
    processingScore,
    connectivityScore,
    hardwareFeatureCount,
  };
}

/**
 * Converts a raw or predicted spec into the exact numeric feature array used by models.
 * Strictly in identical order:
 * [ram, internal_storage, battery_capacity, screen_size, primary_camera, front_camera,
 *  processor_speed, processor_cores, five_g, dual_sim, fast_charging, memory_score,
 *  camera_score, processing_score, connectivity_score, hardware_feature_count]
 */
export function extractFeatureVector(input: PredictionInput): number[] {
  const eng = calculateEngineeredFeatures(input);
  return [
    input.ram,
    input.internalStorage,
    input.batteryCapacity,
    input.screenSize,
    input.primaryCamera,
    input.frontCamera,
    input.processorSpeed,
    input.processorCores,
    input.fiveG,
    input.dualSim,
    input.fastCharging,
    eng.memoryScore,
    eng.cameraScore,
    eng.processingScore,
    eng.connectivityScore,
    eng.hardwareFeatureCount,
  ];
}
