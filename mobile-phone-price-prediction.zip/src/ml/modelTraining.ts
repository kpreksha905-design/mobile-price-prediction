import {
  MobilePhone,
  PriceCategory,
  TrainingResult,
  PredictionInput,
  PredictionResult,
  PRICE_CATEGORY_LABELS,
} from '../types';
import { extractFeatureVector, FEATURE_NAMES } from './featureEngineering';
import { DecisionTreeClassifier } from './decisionTree';
import { RandomForestClassifier } from './randomForest';
import { calculateClassificationMetrics } from '../utils/metrics';

export interface TrainedModelsContainer {
  decisionTree: DecisionTreeClassifier;
  randomForest: RandomForestClassifier;
  trainingResult: TrainingResult;
}

/**
 * Stratified 80/20 train/test split.
 * Ensures each price category is fairly represented in test set.
 */
export function stratifiedTrainTestSplit(
  phones: MobilePhone[],
  testRatio = 0.2
): { train: MobilePhone[]; test: MobilePhone[] } {
  // Group by price category
  const groups: Record<number, MobilePhone[]> = {};
  for (const p of phones) {
    if (!groups[p.priceCategory]) groups[p.priceCategory] = [];
    groups[p.priceCategory].push(p);
  }

  const train: MobilePhone[] = [];
  const test: MobilePhone[] = [];

  for (const catKey of Object.keys(groups)) {
    const list = [...groups[Number(catKey)]];
    // Deterministic pseudo-shuffle
    for (let i = list.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [list[i], list[j]] = [list[j], list[i]];
    }

    const testCount = Math.max(1, Math.round(list.length * testRatio));
    const catTest = list.slice(0, testCount);
    const catTrain = list.slice(testCount);

    test.push(...catTest);
    train.push(...catTrain);
  }

  return { train, test };
}

/**
 * Trains Decision Tree and Random Forest classifiers dynamically on the dataset.
 */
export function trainModels(phones: MobilePhone[]): TrainedModelsContainer {
  if (phones.length < 10) {
    throw new Error('Insufficient dataset records to perform 80/20 stratified split and model training.');
  }

  const { train, test } = stratifiedTrainTestSplit(phones, 0.2);

  // Extract feature matrices and target vectors
  const trainX = train.map(p => extractFeatureVector(p));
  const trainY = train.map(p => p.priceCategory);

  const testX = test.map(p => extractFeatureVector(p));
  const testY = test.map(p => p.priceCategory);

  // 1. Train Decision Tree
  const dt = new DecisionTreeClassifier({
    maxDepth: 5,
    minSamplesSplit: 3,
    minSamplesLeaf: 2,
  });
  dt.fit(trainX, trainY);

  // 2. Train Random Forest
  const rf = new RandomForestClassifier({
    nEstimators: 18,
    maxDepth: 5,
    minSamplesSplit: 3,
    minSamplesLeaf: 2,
  });
  rf.fit(trainX, trainY);

  // 3. Test Predictions
  const dtPreds = testX.map(x => dt.predict(x));
  const rfPreds = testX.map(x => rf.predict(x));

  // 4. Calculate real test metrics
  const dtMetrics = calculateClassificationMetrics('Decision Tree', testY, dtPreds, dt.featureImportances);
  const rfMetrics = calculateClassificationMetrics('Random Forest', testY, rfPreds, rf.featureImportances);

  // 5. Determine Best Model dynamically using Weighted F1 score (with Accuracy as secondary)
  let bestModel: 'Decision Tree' | 'Random Forest' = 'Random Forest';
  if (dtMetrics.f1Weighted > rfMetrics.f1Weighted) {
    bestModel = 'Decision Tree';
  } else if (rfMetrics.f1Weighted > dtMetrics.f1Weighted) {
    bestModel = 'Random Forest';
  } else {
    // If tied on F1, compare accuracy
    bestModel = dtMetrics.accuracy >= rfMetrics.accuracy ? 'Decision Tree' : 'Random Forest';
  }

  const trainingResult: TrainingResult = {
    decisionTree: dtMetrics,
    randomForest: rfMetrics,
    bestModel,
    trainCount: train.length,
    testCount: test.length,
    featureCount: FEATURE_NAMES.length,
    features: FEATURE_NAMES,
    trainedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
  };

  return {
    decisionTree: dt,
    randomForest: rf,
    trainingResult,
  };
}

/**
 * Inference helper for Decision Tree with input specs
 */
export function predictWithDecisionTree(
  model: DecisionTreeClassifier,
  input: PredictionInput
): PredictionResult {
  const features = extractFeatureVector(input);
  const probabilities = model.predictProbabilities(features);
  const predictedCategory = model.predict(features);
  const confidence = probabilities[predictedCategory] || 0;

  return {
    predictedCategory,
    categoryName: PRICE_CATEGORY_LABELS[predictedCategory],
    confidence,
    probabilities,
    modelUsed: 'Decision Tree',
    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
    input,
  };
}

/**
 * Inference helper for Random Forest with input specs
 */
export function predictWithRandomForest(
  model: RandomForestClassifier,
  input: PredictionInput
): PredictionResult {
  const features = extractFeatureVector(input);
  const probabilities = model.predictProbabilities(features);
  const predictedCategory = model.predict(features);
  const confidence = probabilities[predictedCategory] || 0;

  return {
    predictedCategory,
    categoryName: PRICE_CATEGORY_LABELS[predictedCategory],
    confidence,
    probabilities,
    modelUsed: 'Random Forest',
    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
    input,
  };
}
