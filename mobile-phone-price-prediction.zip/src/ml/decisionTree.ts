import { PriceCategory } from '../types';

export interface DecisionTreeNode {
  isLeaf: boolean;
  featureIndex?: number;
  threshold?: number;
  left?: DecisionTreeNode;
  right?: DecisionTreeNode;
  probabilities: Record<PriceCategory, number>;
  predictedClass: PriceCategory;
  samples: number;
  gini: number;
}

export interface DecisionTreeOptions {
  maxDepth?: number;
  minSamplesSplit?: number;
  minSamplesLeaf?: number;
  maxFeatures?: number; // For Random Forest subset of features
}

export class DecisionTreeClassifier {
  root: DecisionTreeNode | null = null;
  maxDepth: number;
  minSamplesSplit: number;
  minSamplesLeaf: number;
  maxFeatures?: number;
  featureImportances: number[] = [];
  classes: PriceCategory[] = [
    PriceCategory.Budget,
    PriceCategory.MidRange,
    PriceCategory.UpperMidRange,
    PriceCategory.Premium,
  ];

  constructor(options: DecisionTreeOptions = {}) {
    this.maxDepth = options.maxDepth ?? 5;
    this.minSamplesSplit = options.minSamplesSplit ?? 4;
    this.minSamplesLeaf = options.minSamplesLeaf ?? 2;
    this.maxFeatures = options.maxFeatures;
  }

  private calculateGini(y: PriceCategory[]): number {
    const total = y.length;
    if (total === 0) return 0;
    const counts: Record<number, number> = {};
    for (const label of y) {
      counts[label] = (counts[label] || 0) + 1;
    }
    let sumSq = 0;
    for (const count of Object.values(counts)) {
      const p = count / total;
      sumSq += p * p;
    }
    return 1 - sumSq;
  }

  private getProbabilities(y: PriceCategory[]): Record<PriceCategory, number> {
    const total = y.length;
    const probs: Record<PriceCategory, number> = {
      [PriceCategory.Budget]: 0,
      [PriceCategory.MidRange]: 0,
      [PriceCategory.UpperMidRange]: 0,
      [PriceCategory.Premium]: 0,
    };
    if (total === 0) return probs;

    for (const label of y) {
      probs[label] = (probs[label] || 0) + 1;
    }

    for (const c of this.classes) {
      probs[c] = total > 0 ? probs[c] / total : 0;
    }
    return probs;
  }

  private getMajorityClass(probs: Record<PriceCategory, number>): PriceCategory {
    let bestClass: PriceCategory = PriceCategory.Budget;
    let maxP = -1;
    for (const c of this.classes) {
      if (probs[c] > maxP) {
        maxP = probs[c];
        bestClass = c;
      }
    }
    return bestClass;
  }

  fit(X: number[][], y: PriceCategory[]): void {
    if (X.length === 0 || y.length === 0) return;
    const numFeatures = X[0].length;
    this.featureImportances = new Array(numFeatures).fill(0);

    const initialGini = this.calculateGini(y);
    const totalSamples = y.length;

    this.root = this.buildTree(X, y, 0, totalSamples);

    // Normalize feature importances so they sum to 1
    const sumImp = this.featureImportances.reduce((a, b) => a + b, 0);
    if (sumImp > 0) {
      this.featureImportances = this.featureImportances.map(v => v / sumImp);
    }
  }

  private buildTree(
    X: number[][],
    y: PriceCategory[],
    depth: number,
    totalDatasetSamples: number
  ): DecisionTreeNode {
    const numSamples = y.length;
    const gini = this.calculateGini(y);
    const probabilities = this.getProbabilities(y);
    const predictedClass = this.getMajorityClass(probabilities);

    // Stop conditions
    if (
      depth >= this.maxDepth ||
      numSamples < this.minSamplesSplit ||
      gini === 0
    ) {
      return {
        isLeaf: true,
        probabilities,
        predictedClass,
        samples: numSamples,
        gini,
      };
    }

    const numFeatures = X[0].length;
    // Determine feature indices to consider (e.g. For Random Forest feature subsampling)
    let featureIndices = Array.from({ length: numFeatures }, (_, i) => i);
    if (this.maxFeatures && this.maxFeatures < numFeatures) {
      // Shuffle and pick maxFeatures
      featureIndices = [...featureIndices].sort(() => 0.5 - Math.random()).slice(0, this.maxFeatures);
    }

    let bestGain = -1;
    let bestFeatureIndex = -1;
    let bestThreshold = 0;
    let bestLeftIndices: number[] = [];
    let bestRightIndices: number[] = [];

    for (const fIdx of featureIndices) {
      const values = X.map(row => row[fIdx]);
      // Candidate thresholds: midpoints of unique sorted values
      const uniqueSorted = Array.from(new Set(values)).sort((a, b) => a - b);
      if (uniqueSorted.length <= 1) continue;

      for (let i = 0; i < uniqueSorted.length - 1; i++) {
        const threshold = (uniqueSorted[i] + uniqueSorted[i + 1]) / 2;

        const leftIdxs: number[] = [];
        const rightIdxs: number[] = [];

        for (let rowIdx = 0; rowIdx < numSamples; rowIdx++) {
          if (X[rowIdx][fIdx] <= threshold) {
            leftIdxs.push(rowIdx);
          } else {
            rightIdxs.push(rowIdx);
          }
        }

        if (leftIdxs.length < this.minSamplesLeaf || rightIdxs.length < this.minSamplesLeaf) {
          continue;
        }

        const leftY = leftIdxs.map(idx => y[idx]);
        const rightY = rightIdxs.map(idx => y[idx]);

        const leftGini = this.calculateGini(leftY);
        const rightGini = this.calculateGini(rightY);

        const currentGain =
          gini -
          ((leftIdxs.length / numSamples) * leftGini +
            (rightIdxs.length / numSamples) * rightGini);

        if (currentGain > bestGain) {
          bestGain = currentGain;
          bestFeatureIndex = fIdx;
          bestThreshold = threshold;
          bestLeftIndices = leftIdxs;
          bestRightIndices = rightIdxs;
        }
      }
    }

    if (bestGain <= 0 || bestLeftIndices.length === 0 || bestRightIndices.length === 0) {
      return {
        isLeaf: true,
        probabilities,
        predictedClass,
        samples: numSamples,
        gini,
      };
    }

    // Accumulate weighted Gini importance for this split
    const splitImportance = (numSamples / totalDatasetSamples) * bestGain;
    this.featureImportances[bestFeatureIndex] += splitImportance;

    const leftX = bestLeftIndices.map(i => X[i]);
    const leftY = bestLeftIndices.map(i => y[i]);
    const rightX = bestRightIndices.map(i => X[i]);
    const rightY = bestRightIndices.map(i => y[i]);

    const leftChild = this.buildTree(leftX, leftY, depth + 1, totalDatasetSamples);
    const rightChild = this.buildTree(rightX, rightY, depth + 1, totalDatasetSamples);

    return {
      isLeaf: false,
      featureIndex: bestFeatureIndex,
      threshold: bestThreshold,
      left: leftChild,
      right: rightChild,
      probabilities,
      predictedClass,
      samples: numSamples,
      gini,
    };
  }

  predictProbabilities(x: number[]): Record<PriceCategory, number> {
    if (!this.root) {
      return {
        [PriceCategory.Budget]: 0.25,
        [PriceCategory.MidRange]: 0.25,
        [PriceCategory.UpperMidRange]: 0.25,
        [PriceCategory.Premium]: 0.25,
      };
    }

    let node: DecisionTreeNode = this.root;
    while (!node.isLeaf) {
      if (node.featureIndex === undefined || node.threshold === undefined) break;
      if (x[node.featureIndex] <= node.threshold) {
        if (!node.left) break;
        node = node.left;
      } else {
        if (!node.right) break;
        node = node.right;
      }
    }

    return node.probabilities;
  }

  predict(x: number[]): PriceCategory {
    const probs = this.predictProbabilities(x);
    return this.getMajorityClass(probs);
  }
}
