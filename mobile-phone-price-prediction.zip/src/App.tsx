import React, { useState, useEffect, useCallback } from 'react';
import {
  MobilePhone,
  DatasetStats,
  TrainingResult,
  PredictionResult,
  PredictionInput,
} from './types';
import { loadMobileDataset } from './services/dataset';
import {
  trainModels,
  TrainedModelsContainer,
  predictWithDecisionTree,
  predictWithRandomForest,
} from './ml/modelTraining';
import {
  calculateCategoryAggregates,
  calculateSpecificationDistributions,
  CategorySpecAggregate,
  SpecificationDistribution,
} from './utils/mobileAnalysis';
import { generateDynamicInsights, DynamicInsightItem } from './utils/insights';
import { generatePdfReport } from './utils/reportGenerator';
import { Sidebar, ActivePage } from './components/Sidebar';
import { Header } from './components/Header';
import { Dashboard } from './pages/Dashboard';
import { PricePredictor } from './pages/PricePredictor';
import { MobileAnalysis } from './pages/MobileAnalysis';
import { ModelPerformance } from './pages/ModelPerformance';
import { Loader2, AlertTriangle, RefreshCw } from 'lucide-react';

export default function App() {
  const [activePage, setActivePage] = useState<ActivePage>('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(false);

  // Data & ML states
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [phones, setPhones] = useState<MobilePhone[]>([]);
  const [stats, setStats] = useState<DatasetStats | null>(null);
  const [categoryAggregates, setCategoryAggregates] = useState<CategorySpecAggregate[]>([]);
  const [distributions, setDistributions] = useState<SpecificationDistribution | null>(null);
  const [insights, setInsights] = useState<DynamicInsightItem[]>([]);
  const [modelsContainer, setModelsContainer] = useState<TrainedModelsContainer | null>(null);
  const [lastPrediction, setLastPrediction] = useState<PredictionResult | null>(null);

  // PDF report state
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);

  // Pipeline initialization
  const initializeSystem = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);

      // 1. Ingest raw CSV data & clean records
      const { phones: cleanPhones, stats: computedStats } = await loadMobileDataset();

      // 2. Hardware analytics & distributions
      const aggs = calculateCategoryAggregates(cleanPhones);
      const dists = calculateSpecificationDistributions(cleanPhones);

      // 3. Train CART Decision Tree & Random Forest models
      const trained = trainModels(cleanPhones);

      // 4. Automated insights
      const dynamicInsights = generateDynamicInsights(computedStats, aggs, trained.trainingResult);

      // 5. Initial benchmark prediction
      const defaultInput: PredictionInput = {
        ram: 8,
        internalStorage: 128,
        batteryCapacity: 5000,
        screenSize: 6.67,
        primaryCamera: 50,
        frontCamera: 16,
        processorSpeed: 2.4,
        processorCores: 8,
        fiveG: 1,
        dualSim: 1,
        fastCharging: 1,
      };

      const initialPrediction = trained.trainingResult.bestModel === 'Decision Tree'
        ? predictWithDecisionTree(trained.decisionTree, defaultInput)
        : predictWithRandomForest(trained.randomForest, defaultInput);

      // 6. Update application state
      setPhones(cleanPhones);
      setStats(computedStats);
      setCategoryAggregates(aggs);
      setDistributions(dists);
      setInsights(dynamicInsights);
      setModelsContainer(trained);
      setLastPrediction(initialPrediction);
    } catch (err: unknown) {
      console.error('Failed to initialize mobile ML engine:', err);
      const msg = err instanceof Error ? err.message : 'Unknown dataset or model error occurred';
      setError(msg);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    initializeSystem();
  }, [initializeSystem]);

  // Model inference handler
  const handlePredict = useCallback((input: PredictionInput, modelType: 'Decision Tree' | 'Random Forest'): PredictionResult => {
    if (!modelsContainer) {
      throw new Error('Models have not been trained yet');
    }

    const result = modelType === 'Decision Tree'
      ? predictWithDecisionTree(modelsContainer.decisionTree, input)
      : predictWithRandomForest(modelsContainer.randomForest, input);

    setLastPrediction(result);
    return result;
  }, [modelsContainer]);

  // PDF Generation handler
  const handleDownloadPdf = async () => {
    if (!stats || !modelsContainer || isGeneratingPdf) return;

    try {
      setIsGeneratingPdf(true);
      await generatePdfReport({
        stats,
        categoryAggregates,
        trainingResult: modelsContainer.trainingResult,
        lastPrediction,
        insights,
      });
    } catch (err) {
      console.error('PDF generation error:', err);
    } finally {
      setIsGeneratingPdf(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-900 flex flex-col items-center justify-center p-6 text-white text-center">
        <div className="w-16 h-16 rounded-2xl bg-slate-800 border border-slate-700 flex items-center justify-center mb-6 shadow-xl">
          <Loader2 className="w-8 h-8 animate-spin text-blue-400" />
        </div>
        <h2 className="text-xl font-bold tracking-tight mb-2">
          Initializing Machine Learning Engine
        </h2>
        <p className="text-xs text-slate-400 max-w-md mb-4 leading-relaxed">
          Loading mobile phone dataset, engineering composite features, and training in-browser CART Decision Tree and Random Forest classifiers...
        </p>
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-800 text-[11px] text-blue-300 font-mono">
          Stratified 80/20 train/test evaluation in progress
        </div>
      </div>
    );
  }

  if (error || !stats || !distributions || !modelsContainer) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-6 text-center">
        <div className="w-16 h-16 rounded-2xl bg-rose-50 border border-rose-200 flex items-center justify-center mb-4 text-rose-600">
          <AlertTriangle className="w-8 h-8" />
        </div>
        <h2 className="text-xl font-bold text-slate-900 mb-2">
          Failed to Load Dataset
        </h2>
        <p className="text-xs text-slate-600 max-w-md mb-6">
          {error || 'Unable to parse mobile specification records.'}
        </p>
        <button
          onClick={initializeSystem}
          className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-slate-900 text-white font-semibold text-xs hover:bg-slate-800 cursor-pointer"
        >
          <RefreshCw className="w-4 h-4" />
          <span>Retry Initialization</span>
        </button>
      </div>
    );
  }

  const trainingResult = modelsContainer.trainingResult;

  return (
    <div className="min-h-screen bg-slate-50 flex">
      {/* Sidebar Navigation */}
      <Sidebar
        activePage={activePage}
        onSelectPage={setActivePage}
        isOpen={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
        phoneCount={phones.length}
        bestModelName={trainingResult.bestModel}
      />

      {/* Main Container */}
      <div className="flex-1 flex flex-col min-w-0 lg:pl-72">
        {/* Top Header */}
        <Header
          onOpenSidebar={() => setSidebarOpen(true)}
          datasetLoaded={phones.length > 0}
          phoneCount={phones.length}
          modelsTrained={modelsContainer !== null}
          bestModelName={trainingResult.bestModel}
          onDownloadReport={handleDownloadPdf}
          isGeneratingPdf={isGeneratingPdf}
        />

        {/* Page Content View */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto">
          {activePage === 'dashboard' && (
            <Dashboard
              stats={stats}
              categoryAggregates={categoryAggregates}
              trainingResult={trainingResult}
              onNavigateToPredictor={() => setActivePage('predictor')}
            />
          )}

          {activePage === 'predictor' && (
            <PricePredictor
              onPredict={handlePredict}
              isReady={modelsContainer !== null}
              bestModelName={trainingResult.bestModel}
              lastPrediction={lastPrediction}
            />
          )}

          {activePage === 'analysis' && (
            <MobileAnalysis
              phones={phones}
              stats={stats}
              aggregates={categoryAggregates}
              distributions={distributions}
              insights={insights}
            />
          )}

          {activePage === 'performance' && (
            <ModelPerformance
              trainingResult={trainingResult}
            />
          )}
        </main>
      </div>
    </div>
  );
}
