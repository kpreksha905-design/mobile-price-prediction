import React from 'react';
import {
  PredictionResult,
  PriceCategory,
  PRICE_CATEGORY_LABELS,
  PRICE_CATEGORY_COLORS,
} from '../types';
import { CheckCircle, ShieldCheck, AlertCircle, Layers } from 'lucide-react';

interface PredictionResultCardProps {
  id?: string;
  result: PredictionResult;
}

export const PredictionResultCard: React.FC<PredictionResultCardProps> = ({
  id,
  result,
}) => {
  const categoryEnum = result.predictedCategory;
  const colors = PRICE_CATEGORY_COLORS[categoryEnum];

  const categories = [
    PriceCategory.Budget,
    PriceCategory.MidRange,
    PriceCategory.UpperMidRange,
    PriceCategory.Premium,
  ];

  return (
    <div id={id} className="bg-white rounded-2xl p-5 sm:p-7 border border-slate-200/90 shadow-2xs space-y-6">
      {/* Top Banner */}
      <div className={`p-6 rounded-2xl border ${colors.bg} ${colors.border} flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4`}>
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Predicted Price Category
            </span>
            <span className="text-xs font-mono px-2 py-0.5 rounded-md bg-white border border-slate-200 text-slate-700 font-semibold">
              Class {result.predictedCategory}
            </span>
          </div>

          <h2 className="text-2xl sm:text-3xl font-black tracking-tight text-slate-900">
            {result.categoryName}
          </h2>

          <div className="flex items-center gap-3 mt-2 text-xs text-slate-600">
            <span className="flex items-center gap-1 font-medium">
              <Layers className="w-3.5 h-3.5 text-slate-500" />
              Inference Model: <strong className="text-slate-800">{result.modelUsed}</strong>
            </span>
            <span>•</span>
            <span className="text-slate-400 font-mono">{result.timestamp}</span>
          </div>
        </div>

        <div className="sm:text-right bg-white/80 backdrop-blur-xs px-4 py-3 rounded-xl border border-slate-200/60 shadow-2xs">
          <span className="text-xs font-medium text-slate-500 block">Prediction Confidence</span>
          <span className="text-2xl font-black text-slate-900">
            {(result.confidence * 100).toFixed(1)}%
          </span>
        </div>
      </div>

      {/* Class Probabilities Distribution */}
      <div>
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-3">
          Trained Model Class Probabilities
        </h3>

        <div className="space-y-3">
          {categories.map(c => {
            const prob = result.probabilities[c] || 0;
            const pct = (prob * 100).toFixed(1);
            const isWinner = c === result.predictedCategory;
            const catColors = PRICE_CATEGORY_COLORS[c];

            return (
              <div
                key={c}
                className={`p-3 rounded-xl border transition-all ${
                  isWinner
                    ? 'bg-slate-50 border-slate-300 shadow-2xs ring-1 ring-slate-300/50'
                    : 'bg-white border-slate-100'
                }`}
              >
                <div className="flex items-center justify-between text-xs mb-1.5">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-slate-800">
                      {PRICE_CATEGORY_LABELS[c]}
                    </span>
                    <span className="text-[10px] font-mono text-slate-400">
                      (Class {c})
                    </span>
                    {isWinner && (
                      <span className="inline-flex items-center gap-1 text-[10px] font-bold px-1.5 py-0.2 rounded-sm bg-slate-900 text-white">
                        <CheckCircle className="w-3 h-3 text-emerald-400" /> Winner
                      </span>
                    )}
                  </div>
                  <span className={`font-mono font-bold ${isWinner ? 'text-slate-900 text-sm' : 'text-slate-500'}`}>
                    {pct}%
                  </span>
                </div>

                {/* Progress bar */}
                <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all duration-500"
                    style={{
                      width: `${Math.max(prob * 100, 1)}%`,
                      backgroundColor: catColors.bar,
                    }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Input Specifications Summary */}
      <div className="p-4 rounded-xl bg-slate-50 border border-slate-100">
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-3">
          Evaluated Phone Specifications
        </h3>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
          <div>
            <span className="text-slate-400 block text-[11px]">RAM</span>
            <span className="font-semibold text-slate-800">{result.input.ram} GB</span>
          </div>
          <div>
            <span className="text-slate-400 block text-[11px]">Storage</span>
            <span className="font-semibold text-slate-800">{result.input.internalStorage} GB</span>
          </div>
          <div>
            <span className="text-slate-400 block text-[11px]">Battery</span>
            <span className="font-semibold text-slate-800">{result.input.batteryCapacity} mAh</span>
          </div>
          <div>
            <span className="text-slate-400 block text-[11px]">Screen Size</span>
            <span className="font-semibold text-slate-800">{result.input.screenSize} in</span>
          </div>
          <div>
            <span className="text-slate-400 block text-[11px]">Main Camera</span>
            <span className="font-semibold text-slate-800">{result.input.primaryCamera} MP</span>
          </div>
          <div>
            <span className="text-slate-400 block text-[11px]">Front Camera</span>
            <span className="font-semibold text-slate-800">{result.input.frontCamera} MP</span>
          </div>
          <div>
            <span className="text-slate-400 block text-[11px]">CPU Clock</span>
            <span className="font-semibold text-slate-800">{result.input.processorSpeed} GHz</span>
          </div>
          <div>
            <span className="text-slate-400 block text-[11px]">Connectivity</span>
            <span className="font-semibold text-slate-800">
              {result.input.fiveG ? '5G' : '4G'}, {result.input.fastCharging ? 'Fast Charge' : 'Std'}
            </span>
          </div>
        </div>
      </div>

      {/* Price Category Interpretation */}
      <div className="pt-2 border-t border-slate-100">
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">
          Category Classification Reference
        </h3>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
          <div className="p-2.5 rounded-lg border border-emerald-100 bg-emerald-50/50">
            <span className="font-mono text-[10px] text-emerald-600 block">Class 0</span>
            <strong className="text-emerald-900 block">Budget</strong>
            <span className="text-[10px] text-emerald-700">Entry specs, 3-4 GB RAM</span>
          </div>
          <div className="p-2.5 rounded-lg border border-blue-100 bg-blue-50/50">
            <span className="font-mono text-[10px] text-blue-600 block">Class 1</span>
            <strong className="text-blue-900 block">Mid-Range</strong>
            <span className="text-[10px] text-blue-700">Balanced 5G, 6 GB RAM</span>
          </div>
          <div className="p-2.5 rounded-lg border border-amber-100 bg-amber-50/50">
            <span className="font-mono text-[10px] text-amber-600 block">Class 2</span>
            <strong className="text-amber-900 block">Upper Mid-Range</strong>
            <span className="text-[10px] text-amber-700">8 GB RAM, high camera res</span>
          </div>
          <div className="p-2.5 rounded-lg border border-purple-100 bg-purple-50/50">
            <span className="font-mono text-[10px] text-purple-600 block">Class 3</span>
            <strong className="text-purple-900 block">Premium</strong>
            <span className="text-[10px] text-purple-700">12+ GB RAM, flagship silicon</span>
          </div>
        </div>

        <p className="text-[11px] text-slate-400 mt-3 italic">
          * Note: This system predicts categorical market tier classification based on hardware configuration, not fluctuating currency pricing.
        </p>
      </div>
    </div>
  );
};
