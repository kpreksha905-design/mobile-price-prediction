import React from 'react';
import { ModelMetrics, PRICE_CATEGORY_LABELS, PriceCategory } from '../types';
import { CheckCircle2, Award, Sparkles } from 'lucide-react';

interface ModelMetricsTableProps {
  id?: string;
  decisionTree: ModelMetrics;
  randomForest: ModelMetrics;
  bestModel: 'Decision Tree' | 'Random Forest';
}

export const ModelMetricsTable: React.FC<ModelMetricsTableProps> = ({
  id,
  decisionTree,
  randomForest,
  bestModel,
}) => {
  const models = [
    { model: decisionTree, isBest: bestModel === 'Decision Tree' },
    { model: randomForest, isBest: bestModel === 'Random Forest' },
  ];

  const categories = [
    PriceCategory.Budget,
    PriceCategory.MidRange,
    PriceCategory.UpperMidRange,
    PriceCategory.Premium,
  ];

  return (
    <div id={id} className="space-y-6">
      {/* Best Model Banner */}
      <div className="bg-linear-to-r from-blue-900 to-indigo-900 rounded-2xl p-5 text-white shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-xl bg-white/10 backdrop-blur-xs flex items-center justify-center shrink-0 border border-white/20">
            <Award className="w-6 h-6 text-amber-300" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs uppercase tracking-wider font-semibold text-blue-200">
                Top Performing Classifier
              </span>
              <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-400/20 text-emerald-300 border border-emerald-400/30">
                <Sparkles className="w-3 h-3" /> Auto Selected
              </span>
            </div>
            <h2 className="text-xl font-bold tracking-tight text-white mt-0.5">
              {bestModel}
            </h2>
            <p className="text-xs text-blue-100/80 mt-1">
              Selected via highest test partition Weighted F1 Score (
              {((bestModel === 'Random Forest' ? randomForest.f1Weighted : decisionTree.f1Weighted) * 100).toFixed(1)}%)
              and Accuracy (
              {((bestModel === 'Random Forest' ? randomForest.accuracy : decisionTree.accuracy) * 100).toFixed(1)}%).
            </p>
          </div>
        </div>

        <div className="flex sm:flex-col items-center sm:items-end justify-between w-full sm:w-auto border-t sm:border-t-0 border-white/10 pt-3 sm:pt-0">
          <span className="text-xs text-blue-200">Test Accuracy</span>
          <span className="text-2xl font-black text-white">
            {((bestModel === 'Random Forest' ? randomForest.accuracy : decisionTree.accuracy) * 100).toFixed(1)}%
          </span>
        </div>
      </div>

      {/* Model Comparison Table */}
      <div className="bg-white rounded-2xl p-5 sm:p-6 border border-slate-200/90 shadow-2xs">
        <div className="mb-4">
          <h2 className="text-base font-bold text-slate-900 tracking-tight">
            Classification Performance Comparison
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Evaluated on held-out 20% stratified test records. Metrics reflect unseen data accuracy and generalization.
          </p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50/70 text-slate-500 uppercase tracking-wider font-semibold">
                <th className="p-3.5 rounded-tl-xl">Model Architecture</th>
                <th className="p-3.5 text-right">Accuracy</th>
                <th className="p-3.5 text-right">Precision (Wtd)</th>
                <th className="p-3.5 text-right">Recall (Wtd)</th>
                <th className="p-3.5 text-right">F1 Score (Wtd)</th>
                <th className="p-3.5 text-right">F1 (Macro)</th>
                <th className="p-3.5 text-center rounded-tr-xl">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {models.map(({ model, isBest }) => (
                <tr
                  key={model.name}
                  className={`hover:bg-slate-50/50 transition-colors ${
                    isBest ? 'bg-blue-50/30' : ''
                  }`}
                >
                  <td className="p-3.5 font-bold text-slate-900 flex items-center gap-2">
                    <span>{model.name}</span>
                    {isBest && (
                      <span className="text-[10px] font-semibold px-2 py-0.5 rounded-md bg-blue-100 text-blue-700">
                        Winner
                      </span>
                    )}
                  </td>
                  <td className="p-3.5 text-right font-mono font-bold text-slate-800 text-sm">
                    {(model.accuracy * 100).toFixed(1)}%
                  </td>
                  <td className="p-3.5 text-right font-mono text-slate-700">
                    {(model.precisionWeighted * 100).toFixed(1)}%
                  </td>
                  <td className="p-3.5 text-right font-mono text-slate-700">
                    {(model.recallWeighted * 100).toFixed(1)}%
                  </td>
                  <td className="p-3.5 text-right font-mono font-bold text-indigo-700 text-sm">
                    {(model.f1Weighted * 100).toFixed(1)}%
                  </td>
                  <td className="p-3.5 text-right font-mono text-slate-500">
                    {(model.f1Macro * 100).toFixed(1)}%
                  </td>
                  <td className="p-3.5 text-center">
                    {isBest ? (
                      <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-600">
                        <CheckCircle2 className="w-4 h-4" /> Active
                      </span>
                    ) : (
                      <span className="text-[11px] text-slate-400">Baseline</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Class-wise Performance Breakdown */}
      <div className="bg-white rounded-2xl p-5 sm:p-6 border border-slate-200/90 shadow-2xs">
        <div className="mb-4">
          <h2 className="text-base font-bold text-slate-900 tracking-tight">
            Class-Wise Performance Breakdown ({bestModel})
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Detailed precision, recall, and F1 score for each price category.
          </p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50/70 text-slate-500 uppercase tracking-wider font-semibold">
                <th className="p-3 rounded-tl-xl">Class / Category</th>
                <th className="p-3 text-right">Precision</th>
                <th className="p-3 text-right">Recall</th>
                <th className="p-3 text-right">F1 Score</th>
                <th className="p-3 text-right rounded-tr-xl">Test Support</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {categories.map(c => {
                const activeModel = bestModel === 'Random Forest' ? randomForest : decisionTree;
                const m = activeModel.classMetrics.find(cm => cm.category === c);
                if (!m) return null;
                return (
                  <tr key={c} className="hover:bg-slate-50/50">
                    <td className="p-3 font-semibold text-slate-800">
                      <span className="font-mono text-slate-400 text-[10px] mr-1.5">[{c}]</span>
                      {PRICE_CATEGORY_LABELS[c]}
                    </td>
                    <td className="p-3 text-right font-mono text-slate-700">
                      {(m.precision * 100).toFixed(1)}%
                    </td>
                    <td className="p-3 text-right font-mono text-slate-700">
                      {(m.recall * 100).toFixed(1)}%
                    </td>
                    <td className="p-3 text-right font-mono font-bold text-slate-900">
                      {(m.f1 * 100).toFixed(1)}%
                    </td>
                    <td className="p-3 text-right font-mono text-slate-500">
                      {m.support} phones
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
