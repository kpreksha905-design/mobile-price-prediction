import React from 'react';
import { ConfusionMatrixRow, PriceCategory, PRICE_CATEGORY_LABELS } from '../types';

interface ConfusionMatrixProps {
  id?: string;
  matrix: ConfusionMatrixRow[];
  modelName: string;
}

export const ConfusionMatrix: React.FC<ConfusionMatrixProps> = ({
  id,
  matrix,
  modelName,
}) => {
  const categories = [
    PriceCategory.Budget,
    PriceCategory.MidRange,
    PriceCategory.UpperMidRange,
    PriceCategory.Premium,
  ];

  // Calculate maximum cell count for heat map intensity
  let maxCell = 1;
  let totalPredictions = 0;
  let totalCorrect = 0;

  matrix.forEach(row => {
    categories.forEach(col => {
      const val = row.predicted[col] || 0;
      totalPredictions += val;
      if (row.actual === col) totalCorrect += val;
      if (val > maxCell) maxCell = val;
    });
  });

  const accuracyPct = totalPredictions > 0 ? ((totalCorrect / totalPredictions) * 100).toFixed(1) : '0';

  return (
    <div id={id} className="bg-white rounded-2xl p-5 sm:p-6 border border-slate-200/90 shadow-2xs">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-6">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-base font-bold text-slate-900 tracking-tight">
              Multiclass Confusion Matrix
            </h2>
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-blue-50 text-blue-700 border border-blue-200">
              {modelName}
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Diagonal cells represent correct class classifications on held-out test data.
          </p>
        </div>

        <div className="text-right">
          <span className="text-xs text-slate-400">Test Accuracy</span>
          <p className="text-lg font-bold text-emerald-600">
            {accuracyPct}% ({totalCorrect}/{totalPredictions})
          </p>
        </div>
      </div>

      {/* Matrix Table with horizontal scroll on small screens */}
      <div className="overflow-x-auto">
        <table className="w-full text-xs text-center border-collapse">
          <thead>
            <tr>
              <th className="p-3 text-left font-bold text-slate-400 uppercase tracking-wider border-b border-slate-200 bg-slate-50/70 rounded-tl-xl w-32">
                Actual \ Pred
              </th>
              {categories.map(c => (
                <th
                  key={c}
                  className="p-3 font-semibold text-slate-700 border-b border-slate-200 bg-slate-50/70 min-w-24"
                >
                  <span className="block text-[10px] text-slate-400 font-mono">Class {c}</span>
                  <span>{PRICE_CATEGORY_LABELS[c]}</span>
                </th>
              ))}
              <th className="p-3 font-semibold text-slate-500 border-b border-slate-200 bg-slate-50/70 rounded-tr-xl min-w-16">
                Total
              </th>
            </tr>
          </thead>
          <tbody>
            {matrix.map((row) => {
              const actCat = row.actual;
              return (
                <tr key={actCat} className="border-b border-slate-100 last:border-0 hover:bg-slate-50/40">
                  <td className="p-3 text-left font-semibold text-slate-800 bg-slate-50/40">
                    <span className="text-[10px] text-slate-400 font-mono block">Class {actCat}</span>
                    <span>{row.actualLabel}</span>
                  </td>

                  {categories.map(predCat => {
                    const count = row.predicted[predCat] || 0;
                    const isDiagonal = actCat === predCat;

                    // Compute dynamic heat map style
                    let bgClass = 'bg-slate-50/50 text-slate-400';
                    if (isDiagonal) {
                      if (count > 0) {
                        bgClass = 'bg-emerald-100 text-emerald-900 font-bold border-2 border-emerald-300 shadow-2xs';
                      } else {
                        bgClass = 'bg-emerald-50/30 text-slate-400';
                      }
                    } else if (count > 0) {
                      bgClass = 'bg-rose-100 text-rose-800 font-semibold border border-rose-200';
                    }

                    return (
                      <td key={predCat} className="p-2.5">
                        <div
                          className={`w-12 h-10 mx-auto rounded-xl flex items-center justify-center text-sm transition-transform hover:scale-105 ${bgClass}`}
                          title={`Actual: ${row.actualLabel}, Predicted: ${PRICE_CATEGORY_LABELS[predCat]} (${count} phones)`}
                        >
                          {count}
                        </div>
                      </td>
                    );
                  })}

                  <td className="p-3 font-bold text-slate-700 bg-slate-50/30">
                    {row.total}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Legend */}
      <div className="mt-4 pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3 text-[11px] text-slate-500">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5">
            <div className="w-3.5 h-3.5 rounded bg-emerald-100 border border-emerald-300" />
            <span>True Positive (Correct)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-3.5 h-3.5 rounded bg-rose-100 border border-rose-200" />
            <span>Misclassification (Error)</span>
          </div>
        </div>
        <span>Evaluated on 20% stratified test partition</span>
      </div>
    </div>
  );
};
