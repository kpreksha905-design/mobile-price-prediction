import React from 'react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Cell,
} from 'recharts';
import { FeatureImportance } from '../types';

interface FeatureImportanceChartProps {
  id?: string;
  features: FeatureImportance[];
  topN?: number;
}

export const FeatureImportanceChart: React.FC<FeatureImportanceChartProps> = ({
  id,
  features,
  topN = 10,
}) => {
  const topFeatures = [...features].slice(0, topN).reverse();

  return (
    <div id={id} className="w-full h-full">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart
          data={topFeatures}
          layout="vertical"
          margin={{ top: 8, right: 30, left: 10, bottom: 8 }}
        >
          <XAxis
            type="number"
            unit="%"
            tick={{ fontSize: 11, fill: '#64748b' }}
            domain={[0, 'dataMax + 2']}
          />
          <YAxis
            type="category"
            dataKey="label"
            width={130}
            tick={{ fontSize: 11, fill: '#334155' }}
          />
          <Tooltip
            formatter={(val: unknown) => {
              const num = typeof val === 'number' ? val : 0;
              return [`${num}%`, 'Importance Weight'];
            }}
            contentStyle={{
              backgroundColor: '#0f172a',
              borderRadius: '12px',
              border: 'none',
              color: '#fff',
              fontSize: '12px',
              boxShadow: '0 4px 12px rgba(0,0,0,0.15)',
            }}
            labelStyle={{ color: '#93c5fd', fontWeight: 'bold' }}
            itemStyle={{ color: '#fff' }}
          />
          <Bar
            dataKey="percentage"
            radius={[0, 6, 6, 0]}
            isAnimationActive={true}
          >
            {topFeatures.map((entry, index) => {
              // Color gradient: higher importance gets deeper blue/indigo
              const isTop = index >= topFeatures.length - 2;
              return (
                <Cell
                  key={`cell-${entry.feature}`}
                  fill={isTop ? '#2563eb' : '#60a5fa'}
                />
              );
            })}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};
