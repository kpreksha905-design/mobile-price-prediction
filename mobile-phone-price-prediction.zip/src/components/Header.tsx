import React from 'react';
import { Menu, FileDown, CheckCircle2, Database, Sparkles, Loader2 } from 'lucide-react';

interface HeaderProps {
  onOpenSidebar: () => void;
  datasetLoaded: boolean;
  phoneCount: number;
  modelsTrained: boolean;
  bestModelName?: string;
  onDownloadReport: () => void;
  isGeneratingPdf: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenSidebar,
  datasetLoaded,
  phoneCount,
  modelsTrained,
  bestModelName,
  onDownloadReport,
  isGeneratingPdf,
}) => {
  return (
    <header
      id="app-header"
      className="h-16 sticky top-0 z-30 bg-white/90 backdrop-blur-md border-b border-slate-200 px-4 sm:px-6 flex items-center justify-between gap-4"
    >
      <div className="flex items-center gap-3">
        <button
          id="open-sidebar-button"
          onClick={onOpenSidebar}
          className="lg:hidden p-2 rounded-xl text-slate-500 hover:text-slate-800 hover:bg-slate-100 transition-colors"
          aria-label="Open navigation menu"
        >
          <Menu className="w-5 h-5" />
        </button>

        <div className="min-w-0">
          <h1 className="text-base sm:text-lg font-bold text-slate-900 tracking-tight truncate">
            Mobile Phone Price Prediction
          </h1>
          <p className="text-[11px] text-slate-500 hidden sm:block truncate">
            Client-Side Hardware Classification &amp; Specification Analytics
          </p>
        </div>
      </div>

      {/* Badges & Actions */}
      <div className="flex items-center gap-2 sm:gap-3 shrink-0">
        {/* Dataset Loaded Badge */}
        {datasetLoaded && (
          <div
            id="status-dataset-badge"
            className="hidden md:flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-50 border border-slate-200 text-xs font-medium text-slate-700"
          >
            <Database className="w-3.5 h-3.5 text-blue-600" />
            <span>{phoneCount} Phones</span>
          </div>
        )}

        {/* Model Trained Badge */}
        {modelsTrained && (
          <div
            id="status-models-badge"
            className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-emerald-50 border border-emerald-200 text-xs font-medium text-emerald-700"
          >
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
            <span>Models Trained</span>
          </div>
        )}

        {/* Best Model Badge */}
        {bestModelName && (
          <div
            id="status-best-model-badge"
            className="hidden lg:flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-purple-50 border border-purple-200 text-xs font-medium text-purple-700"
          >
            <Sparkles className="w-3.5 h-3.5 text-purple-600" />
            <span>Best: {bestModelName}</span>
          </div>
        )}

        {/* Download PDF Report Button */}
        <button
          id="download-pdf-report-button"
          onClick={onDownloadReport}
          disabled={isGeneratingPdf || !datasetLoaded || !modelsTrained}
          className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 active:bg-slate-950 disabled:bg-slate-300 text-white text-xs sm:text-sm font-semibold shadow-xs transition-all cursor-pointer disabled:cursor-not-allowed"
          title="Generate comprehensive 5-page PDF report"
        >
          {isGeneratingPdf ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin text-blue-400" />
              <span className="hidden sm:inline">Generating PDF...</span>
            </>
          ) : (
            <>
              <FileDown className="w-4 h-4 text-blue-400" />
              <span>Download Report</span>
            </>
          )}
        </button>
      </div>
    </header>
  );
};
