import React, { useState } from 'react';
import { PredictionInput } from '../types';
import { Cpu, HardDrive, Camera, BatteryCharging, Sparkles, RefreshCw } from 'lucide-react';

interface PricePredictionFormProps {
  onPredict: (input: PredictionInput, model: 'Decision Tree' | 'Random Forest') => void;
  isTraining: boolean;
  bestModelName: 'Decision Tree' | 'Random Forest';
}

export const PricePredictionForm: React.FC<PricePredictionFormProps> = ({
  onPredict,
  isTraining,
  bestModelName,
}) => {
  const [selectedModel, setSelectedModel] = useState<'Decision Tree' | 'Random Forest'>(bestModelName);

  // Form state
  const [ram, setRam] = useState<number>(8);
  const [internalStorage, setInternalStorage] = useState<number>(128);
  const [batteryCapacity, setBatteryCapacity] = useState<number>(5000);
  const [screenSize, setScreenSize] = useState<number>(6.67);
  const [primaryCamera, setPrimaryCamera] = useState<number>(50);
  const [frontCamera, setFrontCamera] = useState<number>(16);
  const [processorSpeed, setProcessorSpeed] = useState<number>(2.4);
  const [processorCores, setProcessorCores] = useState<number>(8);
  const [fiveG, setFiveG] = useState<number>(1);
  const [dualSim, setDualSim] = useState<number>(1);
  const [fastCharging, setFastCharging] = useState<number>(1);

  const presets = [
    {
      name: 'Budget Tier Preset',
      desc: '3-4 GB RAM, 64 GB, 4G, 2.0 GHz',
      apply: () => {
        setRam(4);
        setInternalStorage(64);
        setBatteryCapacity(5000);
        setScreenSize(6.5);
        setPrimaryCamera(50);
        setFrontCamera(8);
        setProcessorSpeed(2.0);
        setProcessorCores(8);
        setFiveG(0);
        setDualSim(1);
        setFastCharging(1);
      },
    },
    {
      name: 'Mid-Range Preset',
      desc: '6 GB RAM, 128 GB, 5G, 2.4 GHz',
      apply: () => {
        setRam(6);
        setInternalStorage(128);
        setBatteryCapacity(5000);
        setScreenSize(6.67);
        setPrimaryCamera(50);
        setFrontCamera(16);
        setProcessorSpeed(2.2);
        setProcessorCores(8);
        setFiveG(1);
        setDualSim(1);
        setFastCharging(1);
      },
    },
    {
      name: 'Upper Mid-Range',
      desc: '8 GB RAM, 256 GB, 64MP, 2.8 GHz',
      apply: () => {
        setRam(8);
        setInternalStorage(256);
        setBatteryCapacity(5000);
        setScreenSize(6.7);
        setPrimaryCamera(64);
        setFrontCamera(32);
        setProcessorSpeed(2.8);
        setProcessorCores(8);
        setFiveG(1);
        setDualSim(1);
        setFastCharging(1);
      },
    },
    {
      name: 'Flagship Premium',
      desc: '12 GB RAM, 512 GB, 200MP, 3.4 GHz',
      apply: () => {
        setRam(12);
        setInternalStorage(512);
        setBatteryCapacity(5000);
        setScreenSize(6.8);
        setPrimaryCamera(200);
        setFrontCamera(32);
        setProcessorSpeed(3.39);
        setProcessorCores(8);
        setFiveG(1);
        setDualSim(1);
        setFastCharging(1);
      },
    },
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onPredict(
      {
        ram,
        internalStorage,
        batteryCapacity,
        screenSize,
        primaryCamera,
        frontCamera,
        processorSpeed,
        processorCores,
        fiveG,
        dualSim,
        fastCharging,
      },
      selectedModel
    );
  };

  return (
    <div id="price-prediction-form-card" className="bg-white rounded-2xl p-5 sm:p-7 border border-slate-200/90 shadow-2xs">
      {/* Header & Preset Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-100">
        <div>
          <h2 className="text-lg font-bold text-slate-900 tracking-tight">
            Phone Specification Input
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            Configure mobile hardware specifications to predict price tier classification.
          </p>
        </div>

        {/* Model Selector */}
        <div className="flex items-center gap-2 bg-slate-100 p-1 rounded-xl">
          <button
            type="button"
            id="select-rf-button"
            onClick={() => setSelectedModel('Random Forest')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              selectedModel === 'Random Forest'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Random Forest {bestModelName === 'Random Forest' ? '★' : ''}
          </button>
          <button
            type="button"
            id="select-dt-button"
            onClick={() => setSelectedModel('Decision Tree')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              selectedModel === 'Decision Tree'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Decision Tree {bestModelName === 'Decision Tree' ? '★' : ''}
          </button>
        </div>
      </div>

      {/* Quick Presets */}
      <div className="py-4">
        <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-2">
          Quick Spec Presets
        </span>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          {presets.map(p => (
            <button
              key={p.name}
              type="button"
              onClick={p.apply}
              className="p-2.5 rounded-xl border border-slate-200 bg-slate-50/70 hover:bg-blue-50 hover:border-blue-200 hover:text-blue-700 text-left transition-all cursor-pointer text-xs group"
            >
              <span className="font-semibold text-slate-800 group-hover:text-blue-800 block truncate">
                {p.name}
              </span>
              <span className="text-[10px] text-slate-500 block truncate mt-0.5">
                {p.desc}
              </span>
            </button>
          ))}
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6 pt-2">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Group 1: Memory & Storage */}
          <div className="space-y-4 p-4 rounded-xl bg-slate-50/50 border border-slate-100">
            <div className="flex items-center gap-2 text-xs font-bold text-slate-700 uppercase tracking-wider">
              <HardDrive className="w-4 h-4 text-blue-600" />
              <span>Memory &amp; Storage</span>
            </div>

            <div className="space-y-3">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  RAM Capacity (GB)
                </label>
                <select
                  id="input-ram"
                  value={ram}
                  onChange={e => setRam(Number(e.target.value))}
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-sm font-medium text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value={2}>2 GB</option>
                  <option value={3}>3 GB</option>
                  <option value={4}>4 GB</option>
                  <option value={6}>6 GB</option>
                  <option value={8}>8 GB</option>
                  <option value={12}>12 GB</option>
                  <option value={16}>16 GB</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Internal Storage (GB)
                </label>
                <select
                  id="input-storage"
                  value={internalStorage}
                  onChange={e => setInternalStorage(Number(e.target.value))}
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-sm font-medium text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value={32}>32 GB</option>
                  <option value={64}>64 GB</option>
                  <option value={128}>128 GB</option>
                  <option value={256}>256 GB</option>
                  <option value={512}>512 GB</option>
                </select>
              </div>
            </div>
          </div>

          {/* Group 2: Performance & CPU */}
          <div className="space-y-4 p-4 rounded-xl bg-slate-50/50 border border-slate-100">
            <div className="flex items-center gap-2 text-xs font-bold text-slate-700 uppercase tracking-wider">
              <Cpu className="w-4 h-4 text-purple-600" />
              <span>Performance &amp; Processing</span>
            </div>

            <div className="space-y-3">
              <div>
                <div className="flex justify-between items-center mb-1">
                  <label className="text-xs font-medium text-slate-700">
                    Processor Speed (Clock Frequency)
                  </label>
                  <span className="text-xs font-mono font-bold text-slate-800">
                    {processorSpeed.toFixed(2)} GHz
                  </span>
                </div>
                <input
                  type="range"
                  id="input-processor-speed"
                  min={1.4}
                  max={3.8}
                  step={0.05}
                  value={processorSpeed}
                  onChange={e => setProcessorSpeed(parseFloat(e.target.value))}
                  className="w-full accent-blue-600 h-1.5 bg-slate-200 rounded-lg cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-slate-400 mt-1">
                  <span>1.4 GHz</span>
                  <span>2.6 GHz</span>
                  <span>3.8 GHz</span>
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Processor Cores
                </label>
                <select
                  id="input-processor-cores"
                  value={processorCores}
                  onChange={e => setProcessorCores(Number(e.target.value))}
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-sm font-medium text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value={4}>4 Cores (Quad-Core)</option>
                  <option value={6}>6 Cores (Hexa-Core / Apple Silicon)</option>
                  <option value={8}>8 Cores (Octa-Core)</option>
                  <option value={9}>9 Cores (Google Tensor)</option>
                </select>
              </div>
            </div>
          </div>

          {/* Group 3: Camera Optics */}
          <div className="space-y-4 p-4 rounded-xl bg-slate-50/50 border border-slate-100">
            <div className="flex items-center gap-2 text-xs font-bold text-slate-700 uppercase tracking-wider">
              <Camera className="w-4 h-4 text-emerald-600" />
              <span>Camera Setup</span>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Primary Camera (MP)
                </label>
                <select
                  id="input-primary-camera"
                  value={primaryCamera}
                  onChange={e => setPrimaryCamera(Number(e.target.value))}
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-sm font-medium text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value={8}>8 MP</option>
                  <option value={12}>12 MP</option>
                  <option value={13}>13 MP</option>
                  <option value={48}>48 MP</option>
                  <option value={50}>50 MP</option>
                  <option value={64}>64 MP</option>
                  <option value={108}>108 MP</option>
                  <option value={200}>200 MP</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Front Camera (MP)
                </label>
                <select
                  id="input-front-camera"
                  value={frontCamera}
                  onChange={e => setFrontCamera(Number(e.target.value))}
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-sm font-medium text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value={5}>5 MP</option>
                  <option value={8}>8 MP</option>
                  <option value={10}>10 MP</option>
                  <option value={12}>12 MP</option>
                  <option value={16}>16 MP</option>
                  <option value={32}>32 MP</option>
                  <option value={50}>50 MP</option>
                </select>
              </div>
            </div>
          </div>

          {/* Group 4: Hardware & Battery */}
          <div className="space-y-4 p-4 rounded-xl bg-slate-50/50 border border-slate-100">
            <div className="flex items-center gap-2 text-xs font-bold text-slate-700 uppercase tracking-wider">
              <BatteryCharging className="w-4 h-4 text-amber-600" />
              <span>Hardware &amp; Battery</span>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Battery (mAh)
                </label>
                <input
                  type="number"
                  id="input-battery"
                  min={2500}
                  max={7000}
                  step={50}
                  value={batteryCapacity}
                  onChange={e => setBatteryCapacity(Number(e.target.value))}
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-sm font-medium text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Screen Size (Inches)
                </label>
                <input
                  type="number"
                  id="input-screen-size"
                  min={5.5}
                  max={8.5}
                  step={0.05}
                  value={screenSize}
                  onChange={e => setScreenSize(parseFloat(e.target.value))}
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-sm font-medium text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
            </div>

            {/* Binary Toggles */}
            <div className="grid grid-cols-3 gap-2 pt-1">
              <div>
                <label className="block text-[11px] font-semibold text-slate-500 mb-1">
                  5G Support
                </label>
                <button
                  type="button"
                  id="toggle-five-g"
                  onClick={() => setFiveG(fiveG === 1 ? 0 : 1)}
                  className={`w-full py-1.5 text-xs font-semibold rounded-lg border transition-all cursor-pointer ${
                    fiveG === 1
                      ? 'bg-blue-600 text-white border-blue-600'
                      : 'bg-white text-slate-600 border-slate-200'
                  }`}
                >
                  {fiveG === 1 ? 'Yes (5G)' : 'No (4G)'}
                </button>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-500 mb-1">
                  Dual SIM
                </label>
                <button
                  type="button"
                  id="toggle-dual-sim"
                  onClick={() => setDualSim(dualSim === 1 ? 0 : 1)}
                  className={`w-full py-1.5 text-xs font-semibold rounded-lg border transition-all cursor-pointer ${
                    dualSim === 1
                      ? 'bg-blue-600 text-white border-blue-600'
                      : 'bg-white text-slate-600 border-slate-200'
                  }`}
                >
                  {dualSim === 1 ? 'Yes' : 'No'}
                </button>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-500 mb-1">
                  Fast Charging
                </label>
                <button
                  type="button"
                  id="toggle-fast-charging"
                  onClick={() => setFastCharging(fastCharging === 1 ? 0 : 1)}
                  className={`w-full py-1.5 text-xs font-semibold rounded-lg border transition-all cursor-pointer ${
                    fastCharging === 1
                      ? 'bg-blue-600 text-white border-blue-600'
                      : 'bg-white text-slate-600 border-slate-200'
                  }`}
                >
                  {fastCharging === 1 ? 'Yes' : 'No'}
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Submit Action */}
        <div className="pt-3 flex flex-col sm:flex-row items-center justify-between gap-4 border-t border-slate-100">
          <span className="text-xs text-slate-500">
            Applying trained <strong className="text-slate-800">{selectedModel}</strong> inference engine.
          </span>

          <button
            type="submit"
            id="predict-price-category-button"
            disabled={isTraining}
            className="w-full sm:w-auto px-8 py-3 rounded-xl bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white font-bold text-sm shadow-sm transition-all flex items-center justify-center gap-2 cursor-pointer disabled:bg-slate-300"
          >
            <Sparkles className="w-4 h-4" />
            <span>Predict Price Category</span>
          </button>
        </div>
      </form>
    </div>
  );
};
