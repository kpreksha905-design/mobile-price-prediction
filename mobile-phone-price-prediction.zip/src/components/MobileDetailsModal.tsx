import React from 'react';
import { MobilePhone, DatasetStats, PRICE_CATEGORY_LABELS, PRICE_CATEGORY_COLORS } from '../types';
import { X, Smartphone, Check, Minus, TrendingUp, TrendingDown } from 'lucide-react';

interface MobileDetailsModalProps {
  phone: MobilePhone | null;
  datasetStats: DatasetStats;
  onClose: () => void;
}

export const MobileDetailsModal: React.FC<MobileDetailsModalProps> = ({
  phone,
  datasetStats,
  onClose,
}) => {
  if (!phone) return null;

  const colors = PRICE_CATEGORY_COLORS[phone.priceCategory];

  // Compare specifications against dataset averages
  const specsCompare = [
    {
      label: 'RAM',
      value: `${phone.ram} GB`,
      avg: `${datasetStats.avgRam} GB`,
      diff: phone.ram - datasetStats.avgRam,
      diffText: `${phone.ram >= datasetStats.avgRam ? '+' : ''}${(phone.ram - datasetStats.avgRam).toFixed(1)} GB`,
      status: phone.ram >= datasetStats.avgRam ? 'above' : 'below',
    },
    {
      label: 'Internal Storage',
      value: `${phone.internalStorage} GB`,
      avg: `${datasetStats.avgStorage} GB`,
      diff: phone.internalStorage - datasetStats.avgStorage,
      diffText: `${phone.internalStorage >= datasetStats.avgStorage ? '+' : ''}${(phone.internalStorage - datasetStats.avgStorage).toFixed(0)} GB`,
      status: phone.internalStorage >= datasetStats.avgStorage ? 'above' : 'below',
    },
    {
      label: 'Battery Capacity',
      value: `${phone.batteryCapacity} mAh`,
      avg: `${datasetStats.avgBattery} mAh`,
      diff: phone.batteryCapacity - datasetStats.avgBattery,
      diffText: `${phone.batteryCapacity >= datasetStats.avgBattery ? '+' : ''}${(phone.batteryCapacity - datasetStats.avgBattery).toFixed(0)} mAh`,
      status: phone.batteryCapacity >= datasetStats.avgBattery ? 'above' : 'below',
    },
    {
      label: 'Screen Size',
      value: `${phone.screenSize} in`,
      avg: `${datasetStats.avgScreenSize} in`,
      diff: phone.screenSize - datasetStats.avgScreenSize,
      diffText: `${phone.screenSize >= datasetStats.avgScreenSize ? '+' : ''}${(phone.screenSize - datasetStats.avgScreenSize).toFixed(2)} in`,
      status: phone.screenSize >= datasetStats.avgScreenSize ? 'above' : 'below',
    },
    {
      label: 'Primary Camera',
      value: `${phone.primaryCamera} MP`,
      avg: `${datasetStats.avgPrimaryCamera} MP`,
      diff: phone.primaryCamera - datasetStats.avgPrimaryCamera,
      diffText: `${phone.primaryCamera >= datasetStats.avgPrimaryCamera ? '+' : ''}${(phone.primaryCamera - datasetStats.avgPrimaryCamera).toFixed(1)} MP`,
      status: phone.primaryCamera >= datasetStats.avgPrimaryCamera ? 'above' : 'below',
    },
    {
      label: 'Processor Speed',
      value: `${phone.processorSpeed} GHz`,
      avg: `${datasetStats.avgProcessorSpeed} GHz`,
      diff: phone.processorSpeed - datasetStats.avgProcessorSpeed,
      diffText: `${phone.processorSpeed >= datasetStats.avgProcessorSpeed ? '+' : ''}${(phone.processorSpeed - datasetStats.avgProcessorSpeed).toFixed(2)} GHz`,
      status: phone.processorSpeed >= datasetStats.avgProcessorSpeed ? 'above' : 'below',
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs">
      <div
        id="mobile-details-modal"
        className="bg-white rounded-3xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-slate-200"
      >
        {/* Modal Header */}
        <div className="p-6 border-b border-slate-100 flex items-start justify-between gap-4 sticky top-0 bg-white/95 backdrop-blur-md z-10">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-slate-900 flex items-center justify-center text-white shrink-0">
              <Smartphone className="w-6 h-6 text-blue-400" />
            </div>
            <div>
              <span className="text-xs font-bold text-blue-600 uppercase tracking-wider">
                {phone.brand}
              </span>
              <h2 className="text-xl font-black text-slate-900 tracking-tight">
                {phone.model}
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className={`text-xs font-bold px-3 py-1 rounded-full border ${colors.bg} ${colors.text} ${colors.border}`}>
              {PRICE_CATEGORY_LABELS[phone.priceCategory]}
            </span>
            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
              aria-label="Close dialog"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-6">
          {/* Comparison with Dataset Benchmark */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">
              Hardware vs. Dataset Average Benchmark
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {specsCompare.map(item => (
                <div key={item.label} className="p-3 rounded-xl bg-slate-50 border border-slate-200/80">
                  <span className="text-[11px] text-slate-500 font-medium block truncate">
                    {item.label}
                  </span>
                  <div className="flex items-baseline gap-1.5 mt-0.5">
                    <span className="text-base font-bold text-slate-900">
                      {item.value}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-[10px] mt-2 pt-2 border-t border-slate-200/60">
                    <span className="text-slate-400">Avg: {item.avg}</span>
                    <span
                      className={`font-semibold flex items-center gap-0.5 ${
                        item.status === 'above' ? 'text-emerald-600' : 'text-slate-500'
                      }`}
                    >
                      {item.status === 'above' ? (
                        <TrendingUp className="w-3 h-3" />
                      ) : (
                        <TrendingDown className="w-3 h-3" />
                      )}
                      {item.diffText}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Full Specification Profile */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">
              Complete Hardware Architecture Profile
            </h3>
            <div className="rounded-2xl border border-slate-200 overflow-hidden divide-y divide-slate-100 text-xs">
              <div className="flex justify-between p-3 bg-slate-50/50">
                <span className="text-slate-500">Device ID</span>
                <span className="font-mono font-semibold text-slate-800">#{phone.id}</span>
              </div>
              <div className="flex justify-between p-3">
                <span className="text-slate-500">Processor Clock &amp; Cores</span>
                <span className="font-semibold text-slate-800">
                  {phone.processorSpeed} GHz ({phone.processorCores} Cores)
                </span>
              </div>
              <div className="flex justify-between p-3 bg-slate-50/50">
                <span className="text-slate-500">Camera Optics</span>
                <span className="font-semibold text-slate-800">
                  {phone.primaryCamera} MP (Main) / {phone.frontCamera} MP (Selfie)
                </span>
              </div>
              <div className="flex justify-between p-3">
                <span className="text-slate-500">5G Cellular Connectivity</span>
                <span className="font-semibold text-slate-800 flex items-center gap-1">
                  {phone.fiveG ? (
                    <span className="text-blue-600 flex items-center gap-0.5">
                      <Check className="w-3.5 h-3.5" /> Supported (5G NR)
                    </span>
                  ) : (
                    <span className="text-slate-400">4G LTE Only</span>
                  )}
                </span>
              </div>
              <div className="flex justify-between p-3 bg-slate-50/50">
                <span className="text-slate-500">Dual SIM Support</span>
                <span className="font-semibold text-slate-800">
                  {phone.dualSim ? 'Dual Nano-SIM' : 'Single SIM'}
                </span>
              </div>
              <div className="flex justify-between p-3">
                <span className="text-slate-500">Fast Charging Standard</span>
                <span className="font-semibold text-slate-800">
                  {phone.fastCharging ? 'Fast Charging Supported' : 'Standard Charging'}
                </span>
              </div>
              <div className="flex justify-between p-3 bg-slate-50/50">
                <span className="text-slate-500">Engineered Feature Scores</span>
                <span className="font-mono text-slate-700">
                  Mem: {phone.memoryScore} | Cam: {phone.cameraScore} | CPU: {phone.processingScore}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-4 px-6 bg-slate-50 border-t border-slate-100 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs cursor-pointer"
          >
            Close Profile
          </button>
        </div>
      </div>
    </div>
  );
};
