import React, { useState, useMemo } from 'react';
import { MobilePhone, PriceCategory, PRICE_CATEGORY_LABELS, PRICE_CATEGORY_COLORS } from '../types';
import { Search, Filter, ArrowUpDown, ChevronLeft, ChevronRight, Eye } from 'lucide-react';

interface MobileTableProps {
  phones: MobilePhone[];
  brands: string[];
  onSelectPhone: (phone: MobilePhone) => void;
}

type SortField = 'brand' | 'model' | 'ram' | 'internalStorage' | 'batteryCapacity' | 'primaryCamera' | 'priceCategory';
type SortOrder = 'asc' | 'desc';

export const MobileTable: React.FC<MobileTableProps> = ({
  phones,
  brands,
  onSelectPhone,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [brandFilter, setBrandFilter] = useState('all');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [ramFilter, setRamFilter] = useState('all');
  const [storageFilter, setStorageFilter] = useState('all');
  const [fiveGFilter, setFiveGFilter] = useState('all');

  const [sortField, setSortField] = useState<SortField>('priceCategory');
  const [sortOrder, setSortOrder] = useState<SortOrder>('asc');
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 12;

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortOrder('asc');
    }
  };

  const filteredPhones = useMemo(() => {
    return phones.filter(p => {
      // Search term
      if (searchTerm) {
        const term = searchTerm.toLowerCase();
        const matchesBrand = p.brand.toLowerCase().includes(term);
        const matchesModel = p.model.toLowerCase().includes(term);
        if (!matchesBrand && !matchesModel) return false;
      }

      // Brand filter
      if (brandFilter !== 'all' && p.brand !== brandFilter) return false;

      // Category filter
      if (categoryFilter !== 'all' && p.priceCategory !== Number(categoryFilter)) return false;

      // RAM filter
      if (ramFilter !== 'all' && p.ram !== Number(ramFilter)) return false;

      // Storage filter
      if (storageFilter !== 'all' && p.internalStorage !== Number(storageFilter)) return false;

      // 5G filter
      if (fiveGFilter !== 'all') {
        const want5G = fiveGFilter === '1';
        if (Boolean(p.fiveG) !== want5G) return false;
      }

      return true;
    });
  }, [phones, searchTerm, brandFilter, categoryFilter, ramFilter, storageFilter, fiveGFilter]);

  const sortedPhones = useMemo(() => {
    return [...filteredPhones].sort((a, b) => {
      let valA: string | number = a[sortField];
      let valB: string | number = b[sortField];

      if (typeof valA === 'string') {
        const cmp = valA.localeCompare(valB as string);
        return sortOrder === 'asc' ? cmp : -cmp;
      }

      return sortOrder === 'asc' ? (valA as number) - (valB as number) : (valB as number) - (valA as number);
    });
  }, [filteredPhones, sortField, sortOrder]);

  const totalPages = Math.max(1, Math.ceil(sortedPhones.length / pageSize));
  const paginatedPhones = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return sortedPhones.slice(start, start + pageSize);
  }, [sortedPhones, currentPage, pageSize]);

  // Reset page on filter changes
  const handleFilterChange = (setter: React.Dispatch<React.SetStateAction<string>>, value: string) => {
    setter(value);
    setCurrentPage(1);
  };

  return (
    <div className="bg-white rounded-2xl p-5 sm:p-6 border border-slate-200/90 shadow-2xs space-y-4">
      {/* Search & Filter Header */}
      <div className="flex flex-col gap-4">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          {/* Search bar */}
          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              id="search-mobile-input"
              value={searchTerm}
              onChange={e => {
                setSearchTerm(e.target.value);
                setCurrentPage(1);
              }}
              placeholder="Search by brand or model (e.g. Galaxy, Pixel, Redmi)..."
              className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm focus:outline-hidden focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all"
            />
          </div>

          <div className="flex items-center gap-2 text-xs text-slate-500 shrink-0">
            <span>Showing <strong className="text-slate-800">{filteredPhones.length}</strong> of {phones.length} phones</span>
          </div>
        </div>

        {/* Filter Dropdowns Row */}
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5 pt-1">
          {/* Brand Filter */}
          <div>
            <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">
              Brand
            </label>
            <select
              id="filter-brand-select"
              value={brandFilter}
              onChange={e => handleFilterChange(setBrandFilter, e.target.value)}
              className="w-full px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg text-xs font-medium text-slate-700"
            >
              <option value="all">All Brands ({brands.length})</option>
              {brands.map(b => (
                <option key={b} value={b}>{b}</option>
              ))}
            </select>
          </div>

          {/* Category Filter */}
          <div>
            <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">
              Category
            </label>
            <select
              id="filter-category-select"
              value={categoryFilter}
              onChange={e => handleFilterChange(setCategoryFilter, e.target.value)}
              className="w-full px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg text-xs font-medium text-slate-700"
            >
              <option value="all">All Categories</option>
              <option value={PriceCategory.Budget}>Budget (0)</option>
              <option value={PriceCategory.MidRange}>Mid-Range (1)</option>
              <option value={PriceCategory.UpperMidRange}>Upper Mid-Range (2)</option>
              <option value={PriceCategory.Premium}>Premium (3)</option>
            </select>
          </div>

          {/* RAM Filter */}
          <div>
            <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">
              RAM (GB)
            </label>
            <select
              id="filter-ram-select"
              value={ramFilter}
              onChange={e => handleFilterChange(setRamFilter, e.target.value)}
              className="w-full px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg text-xs font-medium text-slate-700"
            >
              <option value="all">All RAMs</option>
              <option value="3">3 GB</option>
              <option value="4">4 GB</option>
              <option value="6">6 GB</option>
              <option value="8">8 GB</option>
              <option value="12">12 GB</option>
              <option value="16">16 GB</option>
            </select>
          </div>

          {/* Storage Filter */}
          <div>
            <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">
              Storage (GB)
            </label>
            <select
              id="filter-storage-select"
              value={storageFilter}
              onChange={e => handleFilterChange(setStorageFilter, e.target.value)}
              className="w-full px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg text-xs font-medium text-slate-700"
            >
              <option value="all">All Storages</option>
              <option value="32">32 GB</option>
              <option value="64">64 GB</option>
              <option value="128">128 GB</option>
              <option value="256">256 GB</option>
              <option value="512">512 GB</option>
            </select>
          </div>

          {/* 5G Filter */}
          <div>
            <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">
              5G Modem
            </label>
            <select
              id="filter-5g-select"
              value={fiveGFilter}
              onChange={e => handleFilterChange(setFiveGFilter, e.target.value)}
              className="w-full px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg text-xs font-medium text-slate-700"
            >
              <option value="all">Any Network</option>
              <option value="1">5G Supported</option>
              <option value="0">4G Only</option>
            </select>
          </div>
        </div>
      </div>

      {/* Table with safe horizontal scroll */}
      <div className="overflow-x-auto rounded-xl border border-slate-200">
        <table className="w-full text-xs text-left border-collapse min-w-[760px]">
          <thead>
            <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-semibold uppercase tracking-wider">
              <th className="p-3">
                <button
                  onClick={() => handleSort('brand')}
                  className="flex items-center gap-1 hover:text-slate-900 cursor-pointer"
                >
                  <span>Brand</span>
                  <ArrowUpDown className="w-3 h-3 text-slate-400" />
                </button>
              </th>
              <th className="p-3">
                <button
                  onClick={() => handleSort('model')}
                  className="flex items-center gap-1 hover:text-slate-900 cursor-pointer"
                >
                  <span>Model</span>
                  <ArrowUpDown className="w-3 h-3 text-slate-400" />
                </button>
              </th>
              <th className="p-3 text-right">
                <button
                  onClick={() => handleSort('ram')}
                  className="flex items-center justify-end gap-1 ml-auto hover:text-slate-900 cursor-pointer"
                >
                  <span>RAM</span>
                  <ArrowUpDown className="w-3 h-3 text-slate-400" />
                </button>
              </th>
              <th className="p-3 text-right">
                <button
                  onClick={() => handleSort('internalStorage')}
                  className="flex items-center justify-end gap-1 ml-auto hover:text-slate-900 cursor-pointer"
                >
                  <span>Storage</span>
                  <ArrowUpDown className="w-3 h-3 text-slate-400" />
                </button>
              </th>
              <th className="p-3 text-right">
                <button
                  onClick={() => handleSort('batteryCapacity')}
                  className="flex items-center justify-end gap-1 ml-auto hover:text-slate-900 cursor-pointer"
                >
                  <span>Battery</span>
                  <ArrowUpDown className="w-3 h-3 text-slate-400" />
                </button>
              </th>
              <th className="p-3 text-right">Screen</th>
              <th className="p-3 text-right">
                <button
                  onClick={() => handleSort('primaryCamera')}
                  className="flex items-center justify-end gap-1 ml-auto hover:text-slate-900 cursor-pointer"
                >
                  <span>Main Cam</span>
                  <ArrowUpDown className="w-3 h-3 text-slate-400" />
                </button>
              </th>
              <th className="p-3 text-right">CPU Clock</th>
              <th className="p-3 text-center">5G</th>
              <th className="p-3 text-center">
                <button
                  onClick={() => handleSort('priceCategory')}
                  className="flex items-center justify-center gap-1 mx-auto hover:text-slate-900 cursor-pointer"
                >
                  <span>Price Tier</span>
                  <ArrowUpDown className="w-3 h-3 text-slate-400" />
                </button>
              </th>
              <th className="p-3 text-center">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {paginatedPhones.length > 0 ? (
              paginatedPhones.map(phone => {
                const colors = PRICE_CATEGORY_COLORS[phone.priceCategory];
                return (
                  <tr
                    key={phone.id}
                    className="hover:bg-slate-50/70 transition-colors cursor-pointer group"
                    onClick={() => onSelectPhone(phone)}
                  >
                    <td className="p-3 font-semibold text-slate-900">
                      {phone.brand}
                    </td>
                    <td className="p-3 font-medium text-slate-800">
                      {phone.model}
                    </td>
                    <td className="p-3 text-right font-mono font-semibold text-slate-700">
                      {phone.ram} GB
                    </td>
                    <td className="p-3 text-right font-mono text-slate-700">
                      {phone.internalStorage} GB
                    </td>
                    <td className="p-3 text-right font-mono text-slate-700">
                      {phone.batteryCapacity} mAh
                    </td>
                    <td className="p-3 text-right font-mono text-slate-700">
                      {phone.screenSize}"
                    </td>
                    <td className="p-3 text-right font-mono text-slate-700">
                      {phone.primaryCamera} MP
                    </td>
                    <td className="p-3 text-right font-mono text-slate-700">
                      {phone.processorSpeed} GHz
                    </td>
                    <td className="p-3 text-center">
                      <span
                        className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                          phone.fiveG
                            ? 'bg-blue-50 text-blue-700 border border-blue-200'
                            : 'bg-slate-100 text-slate-500'
                        }`}
                      >
                        {phone.fiveG ? '5G' : '4G'}
                      </span>
                    </td>
                    <td className="p-3 text-center">
                      <span
                        className={`text-[11px] font-semibold px-2 py-0.5 rounded-full border ${colors.bg} ${colors.text} ${colors.border}`}
                      >
                        {PRICE_CATEGORY_LABELS[phone.priceCategory]}
                      </span>
                    </td>
                    <td className="p-3 text-center">
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onSelectPhone(phone);
                        }}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-blue-600 hover:bg-blue-50 transition-colors"
                        title="View Full Phone Profile"
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                );
              })
            ) : (
              <tr>
                <td colSpan={11} className="p-8 text-center text-slate-400">
                  No mobile phones match the selected search and filter criteria.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination Footer */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2 text-xs text-slate-500">
        <span>
          Page <strong className="text-slate-800">{currentPage}</strong> of {totalPages} ({sortedPhones.length} filtered models)
        </span>

        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
            disabled={currentPage === 1}
            className="p-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
            aria-label="Previous page"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <button
            onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
            disabled={currentPage === totalPages}
            className="p-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
            aria-label="Next page"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
