import { DatasetStats, TrainingResult, PriceCategory } from '../types';
import { CategorySpecAggregate } from './mobileAnalysis';

export interface DynamicInsightItem {
  id: string;
  category: 'Dataset' | 'Hardware' | 'Model' | 'Feature';
  title: string;
  description: string;
  badge: string;
}

export function generateDynamicInsights(
  stats: DatasetStats,
  categoryAggregates: CategorySpecAggregate[],
  trainingResult?: TrainingResult
): DynamicInsightItem[] {
  const insights: DynamicInsightItem[] = [];

  // Insight 1: Most Common Category & Distribution
  const mostCommon = stats.mostCommonCategory;
  const commonCount = stats.categoryCounts[
    mostCommon === 'Budget' ? PriceCategory.Budget :
    mostCommon === 'Mid-Range' ? PriceCategory.MidRange :
    mostCommon === 'Upper Mid-Range' ? PriceCategory.UpperMidRange : PriceCategory.Premium
  ] || 0;
  const commonPct = stats.totalPhones > 0 ? ((commonCount / stats.totalPhones) * 100).toFixed(1) : '0';

  insights.push({
    id: 'most-common-category',
    category: 'Dataset',
    title: 'Category Market Distribution',
    description: `The most frequent segment in the dataset is ${mostCommon}, comprising ${commonPct}% (${commonCount} of ${stats.totalPhones} models).`,
    badge: `${commonPct}% Share`,
  });

  // Insight 2: Premium Hardware Thresholds
  const premiumAgg = categoryAggregates.find(a => a.category === PriceCategory.Premium);
  const budgetAgg = categoryAggregates.find(a => a.category === PriceCategory.Budget);

  if (premiumAgg && budgetAgg) {
    insights.push({
      id: 'ram-scaling',
      category: 'Hardware',
      title: 'RAM & Memory Scaling Across Tiers',
      description: `Phones in the Premium category feature an average of ${premiumAgg.avgRam} GB RAM and ${premiumAgg.avgStorage} GB storage, compared to ${budgetAgg.avgRam} GB RAM in Budget models.`,
      badge: `${premiumAgg.avgRam} GB vs ${budgetAgg.avgRam} GB`,
    });

    insights.push({
      id: 'processor-gap',
      category: 'Hardware',
      title: 'Silicon Clock Frequencies',
      description: `Premium flagships average ${premiumAgg.avgProcessorSpeed} GHz clock speeds with high-efficiency clusters, outperforming the Budget tier baseline of ${budgetAgg.avgProcessorSpeed} GHz.`,
      badge: `+${(premiumAgg.avgProcessorSpeed - budgetAgg.avgProcessorSpeed).toFixed(2)} GHz Gap`,
    });
  }

  // Insight 3: 5G & Fast Charging Penetration
  insights.push({
    id: 'connectivity-adoption',
    category: 'Hardware',
    title: '5G Modern Standard Adoption',
    description: `${stats.fiveGPercent}% of analyzed phones include 5G modems, with ${stats.fastChargingPercent}% equipped with fast-charging technology.`,
    badge: `${stats.fiveGPercent}% 5G`,
  });

  // Insight 4: Best Machine Learning Classifier
  if (trainingResult) {
    const bestModelName = trainingResult.bestModel;
    const bestMetrics = bestModelName === 'Random Forest' ? trainingResult.randomForest : trainingResult.decisionTree;
    const runnerUpMetrics = bestModelName === 'Random Forest' ? trainingResult.decisionTree : trainingResult.randomForest;

    insights.push({
      id: 'best-classifier',
      category: 'Model',
      title: 'Optimal Classifier Performance',
      description: `The best performing classifier is ${bestModelName}, achieving ${(bestMetrics.accuracy * 100).toFixed(1)}% test accuracy and a ${(bestMetrics.f1Weighted * 100).toFixed(1)}% weighted F1 score on unseen records.`,
      badge: `${bestModelName} (F1: ${(bestMetrics.f1Weighted * 100).toFixed(1)}%)`,
    });

    // Insight 5: Top Influential Specification
    if (trainingResult.randomForest.featureImportances.length > 0) {
      const topFeature = trainingResult.randomForest.featureImportances[0];
      const secondFeature = trainingResult.randomForest.featureImportances[1];

      insights.push({
        id: 'top-feature-importance',
        category: 'Feature',
        title: 'Primary Price Determining Factor',
        description: `The most influential specification is ${topFeature.label} (${topFeature.percentage}% importance), followed closely by ${secondFeature ? secondFeature.label : 'Storage'}.`,
        badge: `${topFeature.label} #${topFeature.percentage}%`,
      });
    }
  }

  return insights;
}
