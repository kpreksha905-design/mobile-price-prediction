import {
  PriceCategory,
  PRICE_CATEGORY_LABELS,
  ModelMetrics,
  ConfusionMatrixRow,
  ClassMetrics,
  FeatureImportance,
} from '../types';
import { FEATURE_NAMES, FEATURE_LABELS } from '../ml/featureEngineering';

const CLASSES = [
  PriceCategory.Budget,
  PriceCategory.MidRange,
  PriceCategory.UpperMidRange,
  PriceCategory.Premium,
];

export function calculateClassificationMetrics(
  name: 'Decision Tree' | 'Random Forest',
  actuals: PriceCategory[],
  predictions: PriceCategory[],
  rawFeatureImportances: number[]
): ModelMetrics {
  const total = actuals.length;
  if (total === 0) {
    return {
      name,
      accuracy: 0,
      precisionMacro: 0,
      recallMacro: 0,
      f1Macro: 0,
      precisionWeighted: 0,
      recallWeighted: 0,
      f1Weighted: 0,
      classMetrics: [],
      confusionMatrix: [],
      featureImportances: [],
    };
  }

  // 1. Accuracy
  let correct = 0;
  for (let i = 0; i < total; i++) {
    if (actuals[i] === predictions[i]) correct++;
  }
  const accuracy = Number((correct / total).toFixed(4));

  // 2. Confusion Matrix
  const matrix: Record<PriceCategory, Record<PriceCategory, number>> = {
    [PriceCategory.Budget]: { [PriceCategory.Budget]: 0, [PriceCategory.MidRange]: 0, [PriceCategory.UpperMidRange]: 0, [PriceCategory.Premium]: 0 },
    [PriceCategory.MidRange]: { [PriceCategory.Budget]: 0, [PriceCategory.MidRange]: 0, [PriceCategory.UpperMidRange]: 0, [PriceCategory.Premium]: 0 },
    [PriceCategory.UpperMidRange]: { [PriceCategory.Budget]: 0, [PriceCategory.MidRange]: 0, [PriceCategory.UpperMidRange]: 0, [PriceCategory.Premium]: 0 },
    [PriceCategory.Premium]: { [PriceCategory.Budget]: 0, [PriceCategory.MidRange]: 0, [PriceCategory.UpperMidRange]: 0, [PriceCategory.Premium]: 0 },
  };

  for (let i = 0; i < total; i++) {
    const act = actuals[i];
    const pred = predictions[i];
    matrix[act][pred] = (matrix[act][pred] || 0) + 1;
  }

  const confusionMatrixRows: ConfusionMatrixRow[] = CLASSES.map(actClass => {
    const rowCounts = matrix[actClass];
    const rowTotal = Object.values(rowCounts).reduce((a, b) => a + b, 0);
    return {
      actual: actClass,
      actualLabel: PRICE_CATEGORY_LABELS[actClass],
      predicted: rowCounts,
      total: rowTotal,
    };
  });

  // 3. Class-wise Metrics
  const classMetrics: ClassMetrics[] = [];
  let sumPrecMacro = 0;
  let sumRecMacro = 0;
  let sumF1Macro = 0;

  let sumPrecWeighted = 0;
  let sumRecWeighted = 0;
  let sumF1Weighted = 0;

  for (const c of CLASSES) {
    const tp = matrix[c][c];
    let fp = 0;
    let fn = 0;

    for (const other of CLASSES) {
      if (other !== c) {
        fp += matrix[other][c]; // predicted as c, but was other
        fn += matrix[c][other]; // was c, but predicted as other
      }
    }

    const support = tp + fn;
    const precision = tp + fp > 0 ? tp / (tp + fp) : 0;
    const recall = tp + fn > 0 ? tp / (tp + fn) : 0;
    const f1 = precision + recall > 0 ? (2 * precision * recall) / (precision + recall) : 0;

    classMetrics.push({
      category: c,
      label: PRICE_CATEGORY_LABELS[c],
      precision: Number(precision.toFixed(4)),
      recall: Number(recall.toFixed(4)),
      f1: Number(f1.toFixed(4)),
      support,
    });

    sumPrecMacro += precision;
    sumRecMacro += recall;
    sumF1Macro += f1;

    sumPrecWeighted += precision * support;
    sumRecWeighted += recall * support;
    sumF1Weighted += f1 * support;
  }

  const numClasses = CLASSES.length;
  const precisionMacro = Number((sumPrecMacro / numClasses).toFixed(4));
  const recallMacro = Number((sumRecMacro / numClasses).toFixed(4));
  const f1Macro = Number((sumF1Macro / numClasses).toFixed(4));

  const precisionWeighted = Number((sumPrecWeighted / total).toFixed(4));
  const recallWeighted = Number((sumRecWeighted / total).toFixed(4));
  const f1Weighted = Number((sumF1Weighted / total).toFixed(4));

  // 4. Feature Importances
  const featureImportances: FeatureImportance[] = rawFeatureImportances
    .map((imp, idx) => {
      const featKey = FEATURE_NAMES[idx] || `feature_${idx}`;
      return {
        feature: featKey,
        label: FEATURE_LABELS[featKey] || featKey,
        importance: Number(imp.toFixed(4)),
        percentage: Number((imp * 100).toFixed(1)),
      };
    })
    .sort((a, b) => b.importance - a.importance);

  return {
    name,
    accuracy,
    precisionMacro,
    recallMacro,
    f1Macro,
    precisionWeighted,
    recallWeighted,
    f1Weighted,
    classMetrics,
    confusionMatrix: confusionMatrixRows,
    featureImportances,
  };
}
