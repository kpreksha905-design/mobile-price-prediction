import { MobilePhone, PriceCategory, PRICE_CATEGORY_LABELS, PRICE_CATEGORY_COLORS } from '../types';

export interface CategorySpecAggregate {
  category: PriceCategory;
  categoryLabel: string;
  count: number;
  avgRam: number;
  minRam: number;
  maxRam: number;
  avgStorage: number;
  avgBattery: number;
  minBattery: number;
  maxBattery: number;
  avgScreenSize: number;
  minScreenSize: number;
  maxScreenSize: number;
  avgPrimaryCam: number;
  avgFrontCam: number;
  avgCameraScore: number;
  avgProcessorSpeed: number;
  avgProcessorCores: number;
  pct5G: number;
  fiveGPercent: number;
  fastChargingPercent: number;
  dualSimPercent: number;
  color: string;
}

export interface SpecificationDistribution {
  ram: { value: string; count: number }[];
  storage: { value: string; count: number }[];
  battery: { range: string; count: number }[];
  screen: { range: string; count: number }[];
  camera: { range: string; count: number }[];
}

export function computeCategoryAnalysis(phones: MobilePhone[]): CategorySpecAggregate[] {
  const categories = [
    PriceCategory.Budget,
    PriceCategory.MidRange,
    PriceCategory.UpperMidRange,
    PriceCategory.Premium,
  ];

  return categories.map(cat => {
    const subset = phones.filter(p => p.priceCategory === cat);
    const count = subset.length;
    const label = PRICE_CATEGORY_LABELS[cat];
    const color = PRICE_CATEGORY_COLORS[cat].bar;

    if (count === 0) {
      return {
        category: cat,
        categoryLabel: label,
        count: 0,
        avgRam: 0,
        minRam: 0,
        maxRam: 0,
        avgStorage: 0,
        avgBattery: 0,
        minBattery: 0,
        maxBattery: 0,
        avgScreenSize: 0,
        minScreenSize: 0,
        maxScreenSize: 0,
        avgPrimaryCam: 0,
        avgFrontCam: 0,
        avgCameraScore: 0,
        avgProcessorSpeed: 0,
        avgProcessorCores: 0,
        pct5G: 0,
        fiveGPercent: 0,
        fastChargingPercent: 0,
        dualSimPercent: 0,
        color,
      };
    }

    const rams = subset.map(p => p.ram);
    const storages = subset.map(p => p.internalStorage);
    const batteries = subset.map(p => p.batteryCapacity);
    const screens = subset.map(p => p.screenSize);
    const primaryCams = subset.map(p => p.primaryCamera);
    const frontCams = subset.map(p => p.frontCamera);
    const camScores = subset.map(p => p.cameraScore);
    const speeds = subset.map(p => p.processorSpeed);
    const cores = subset.map(p => p.processorCores);

    const fiveGCount = subset.filter(p => p.fiveG === 1).length;
    const fastCount = subset.filter(p => p.fastCharging === 1).length;
    const dualCount = subset.filter(p => p.dualSim === 1).length;

    const avg = (arr: number[]) => arr.reduce((a, b) => a + b, 0) / arr.length;
    const pct5GVal = Number(((fiveGCount / count) * 100).toFixed(1));

    return {
      category: cat,
      categoryLabel: label,
      count,
      avgRam: Number(avg(rams).toFixed(1)),
      minRam: Math.min(...rams),
      maxRam: Math.max(...rams),
      avgStorage: Number(avg(storages).toFixed(0)),
      avgBattery: Number(avg(batteries).toFixed(0)),
      minBattery: Math.min(...batteries),
      maxBattery: Math.max(...batteries),
      avgScreenSize: Number(avg(screens).toFixed(2)),
      minScreenSize: Math.min(...screens),
      maxScreenSize: Math.max(...screens),
      avgPrimaryCam: Number(avg(primaryCams).toFixed(1)),
      avgFrontCam: Number(avg(frontCams).toFixed(1)),
      avgCameraScore: Number(avg(camScores).toFixed(2)),
      avgProcessorSpeed: Number(avg(speeds).toFixed(2)),
      avgProcessorCores: Number(avg(cores).toFixed(1)),
      pct5G: pct5GVal,
      fiveGPercent: pct5GVal,
      fastChargingPercent: Number(((fastCount / count) * 100).toFixed(1)),
      dualSimPercent: Number(((dualCount / count) * 100).toFixed(1)),
      color,
    };
  });
}

export const calculateCategoryAggregates = computeCategoryAnalysis;

export function computeRamDistribution(phones: MobilePhone[]) {
  const buckets = [2, 3, 4, 6, 8, 12, 16];
  return buckets.map(ram => {
    const count = phones.filter(p => p.ram === ram).length;
    return {
      value: `${ram} GB`,
      count,
    };
  });
}

export function computeStorageDistribution(phones: MobilePhone[]) {
  const buckets = [32, 64, 128, 256, 512];
  return buckets.map(storage => {
    const count = phones.filter(p => p.internalStorage === storage).length;
    return {
      value: `${storage} GB`,
      count,
    };
  });
}

export function computeBatteryDistribution(phones: MobilePhone[]) {
  const ranges = [
    { label: '< 4000 mAh', min: 0, max: 3999 },
    { label: '4000-4500', min: 4000, max: 4500 },
    { label: '4501-5000', min: 4501, max: 5000 },
    { label: '5001-5500', min: 5001, max: 5500 },
    { label: '5501-6000+', min: 5501, max: 99999 },
  ];
  return ranges.map(r => {
    const count = phones.filter(p => p.batteryCapacity >= r.min && p.batteryCapacity <= r.max).length;
    return {
      range: r.label,
      count,
    };
  });
}

export function computeScreenDistribution(phones: MobilePhone[]) {
  const ranges = [
    { label: '≤ 6.2"', min: 0, max: 6.2 },
    { label: '6.3" - 6.5"', min: 6.21, max: 6.55 },
    { label: '6.6" - 6.7"', min: 6.56, max: 6.74 },
    { label: '≥ 6.75"', min: 6.75, max: 10 },
  ];
  return ranges.map(r => {
    const count = phones.filter(p => p.screenSize >= r.min && p.screenSize <= r.max).length;
    return {
      range: r.label,
      count,
    };
  });
}

export function computeCameraDistribution(phones: MobilePhone[]) {
  const ranges = [
    { label: '≤ 13 MP', min: 0, max: 13 },
    { label: '48-50 MP', min: 40, max: 55 },
    { label: '64 MP', min: 56, max: 80 },
    { label: '108 MP', min: 81, max: 150 },
    { label: '200 MP', min: 151, max: 300 },
  ];
  return ranges.map(r => {
    const count = phones.filter(p => p.primaryCamera >= r.min && p.primaryCamera <= r.max).length;
    return {
      range: r.label,
      count,
    };
  });
}

export function calculateSpecificationDistributions(phones: MobilePhone[]): SpecificationDistribution {
  return {
    ram: computeRamDistribution(phones),
    storage: computeStorageDistribution(phones),
    battery: computeBatteryDistribution(phones),
    screen: computeScreenDistribution(phones),
    camera: computeCameraDistribution(phones),
  };
}
