import jsPDF from 'jspdf';
import {
  DatasetStats,
  TrainingResult,
  PredictionResult,
  PRICE_CATEGORY_LABELS,
  PriceCategory,
} from '../types';
import { CategorySpecAggregate } from './mobileAnalysis';
import { DynamicInsightItem } from './insights';

interface GenerateReportOptions {
  stats: DatasetStats;
  categoryAggregates: CategorySpecAggregate[];
  trainingResult: TrainingResult;
  lastPrediction: PredictionResult | null;
  insights: DynamicInsightItem[];
}

export async function generatePdfReport(options: GenerateReportOptions): Promise<void> {
  const { stats, categoryAggregates, trainingResult, lastPrediction, insights } = options;

  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const margin = 18;
  const contentWidth = pageWidth - margin * 2;

  // Header helper
  const addHeader = (title: string, subtitle: string, pageNum: number) => {
    // Header banner accent line
    doc.setFillColor(30, 41, 59); // slate-800
    doc.rect(margin, 12, contentWidth, 1.5, 'F');

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(15);
    doc.setTextColor(15, 23, 42); // slate-900
    doc.text(title, margin, 22);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9);
    doc.setTextColor(100, 116, 139); // slate-500
    doc.text(subtitle, margin, 27);

    // Date & page number
    doc.setFontSize(8);
    doc.text(`Generated: ${new Date().toLocaleDateString()}`, pageWidth - margin - 35, 22);
    doc.text(`Page ${pageNum} of 5`, pageWidth - margin - 20, 27);

    // Divider
    doc.setDrawColor(226, 232, 240);
    doc.line(margin, 31, pageWidth - margin, 31);
  };

  const addFooter = (pageNum: number) => {
    doc.setDrawColor(226, 232, 240);
    doc.line(margin, pageHeight - 15, pageWidth - margin, pageHeight - 15);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.setTextColor(148, 163, 184);
    doc.text('Mobile Phone Price Prediction — Machine Learning Analytics Report', margin, pageHeight - 10);
    doc.text(`Page ${pageNum} of 5`, pageWidth - margin - 18, pageHeight - 10);
  };

  // ==========================================
  // PAGE 1: Dataset Overview
  // ==========================================
  addHeader('Mobile Phone Price Prediction', 'Page 1 — Dataset Overview & Inventory Summary', 1);

  let y = 42;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(12);
  doc.setTextColor(30, 41, 59);
  doc.text('1. Dataset Characteristics & Summary', margin, y);

  y += 8;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9.5);
  doc.setTextColor(71, 85, 105);
  doc.text(
    'This report summarizes historical mobile hardware specifications loaded from a real local dataset and evaluates in-browser Decision Tree and Random Forest classifiers predicting price tier categories (Budget, Mid-Range, Upper Mid-Range, and Premium).',
    margin,
    y,
    { maxWidth: contentWidth }
  );

  y += 18;
  // Key Metrics Table / Grid
  doc.setFillColor(248, 250, 252);
  doc.setDrawColor(226, 232, 240);
  doc.roundedRect(margin, y, contentWidth, 42, 2, 2, 'FD');

  const statItems = [
    { label: 'Total Mobile Models', value: `${stats.totalPhones} Phones` },
    { label: 'Price Categories', value: `${stats.totalCategories} Tiers` },
    { label: 'Average RAM', value: `${stats.avgRam} GB` },
    { label: 'Average Storage', value: `${stats.avgStorage} GB` },
    { label: 'Average Battery', value: `${stats.avgBattery} mAh` },
    { label: 'Average Screen Size', value: `${stats.avgScreenSize} in` },
    { label: '5G Modem Support', value: `${stats.fiveGPercent}%` },
    { label: 'Fast Charging Tech', value: `${stats.fastChargingPercent}%` },
  ];

  const colW = contentWidth / 4;
  statItems.forEach((item, idx) => {
    const col = idx % 4;
    const row = Math.floor(idx / 4);
    const cellX = margin + col * colW + 4;
    const cellY = y + 10 + row * 18;

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.setTextColor(100, 116, 139);
    doc.text(item.label, cellX, cellY);

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.setTextColor(15, 23, 42);
    doc.text(item.value, cellX, cellY + 5.5);
  });

  y += 52;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(30, 41, 59);
  doc.text('2. Price Category Distribution', margin, y);

  y += 6;
  // Table for Category breakdown
  doc.setFillColor(241, 245, 249);
  doc.rect(margin, y, contentWidth, 8, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.setTextColor(51, 65, 85);
  doc.text('Category Code', margin + 4, y + 5.5);
  doc.text('Category Name', margin + 35, y + 5.5);
  doc.text('Phone Count', margin + 85, y + 5.5);
  doc.text('Share (%)', margin + 125, y + 5.5);
  doc.text('Hardware Profile Summary', margin + 155, y + 5.5);

  y += 8;
  const cats = [PriceCategory.Budget, PriceCategory.MidRange, PriceCategory.UpperMidRange, PriceCategory.Premium];
  cats.forEach((c) => {
    const agg = categoryAggregates.find(a => a.category === c);
    const count = agg ? agg.count : 0;
    const pct = stats.totalPhones > 0 ? ((count / stats.totalPhones) * 100).toFixed(1) : '0';
    const profile = agg ? `${agg.avgRam}GB RAM | ${agg.avgStorage}GB ROM | ${agg.avgBattery}mAh` : 'N/A';

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8.5);
    doc.setTextColor(51, 65, 85);
    doc.text(String(c), margin + 8, y + 5.5);
    doc.text(PRICE_CATEGORY_LABELS[c], margin + 35, y + 5.5);
    doc.text(String(count), margin + 92, y + 5.5);
    doc.text(`${pct}%`, margin + 130, y + 5.5);
    doc.text(profile, margin + 155, y + 5.5);

    doc.setDrawColor(241, 245, 249);
    doc.line(margin, y + 8, pageWidth - margin, y + 8);
    y += 9;
  });

  y += 10;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(30, 41, 59);
  doc.text('3. Dataset Integrity & Preprocessing Audit', margin, y);

  y += 6;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(71, 85, 105);
  doc.text(
    `All rows verified against hardware schema. Binary normalization applied for 5G, Dual SIM, and Fast Charging. Numerical columns median-imputed where missing. Duplicate detection executed prior to 80/20 stratified partitioning.`,
    margin,
    y,
    { maxWidth: contentWidth }
  );

  addFooter(1);

  // ==========================================
  // PAGE 2: Specification Analysis
  // ==========================================
  doc.addPage();
  addHeader('Specification Analysis Across Price Tiers', 'Page 2 — Detailed Hardware Architecture Breakdown', 2);

  y = 42;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(30, 41, 59);
  doc.text('Category Hardware Benchmark Matrix', margin, y);

  y += 6;
  // Comprehensive table
  doc.setFillColor(241, 245, 249);
  doc.rect(margin, y, contentWidth, 8, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(51, 65, 85);
  doc.text('Tier', margin + 3, y + 5.5);
  doc.text('Avg RAM', margin + 35, y + 5.5);
  doc.text('Storage', margin + 60, y + 5.5);
  doc.text('Battery', margin + 85, y + 5.5);
  doc.text('Screen', margin + 110, y + 5.5);
  doc.text('Main Cam', margin + 130, y + 5.5);
  doc.text('CPU Clock', margin + 152, y + 5.5);
  doc.text('5G %', margin + 175, y + 5.5);

  y += 8;
  categoryAggregates.forEach(agg => {
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.setTextColor(51, 65, 85);
    doc.text(agg.categoryLabel, margin + 3, y + 5.5);
    doc.text(`${agg.avgRam} GB`, margin + 35, y + 5.5);
    doc.text(`${agg.avgStorage} GB`, margin + 60, y + 5.5);
    doc.text(`${agg.avgBattery} mAh`, margin + 85, y + 5.5);
    doc.text(`${agg.avgScreenSize}"`, margin + 110, y + 5.5);
    doc.text(`${agg.avgPrimaryCam} MP`, margin + 130, y + 5.5);
    doc.text(`${agg.avgProcessorSpeed} GHz`, margin + 152, y + 5.5);
    doc.text(`${agg.fiveGPercent}%`, margin + 175, y + 5.5);

    doc.setDrawColor(241, 245, 249);
    doc.line(margin, y + 8, pageWidth - margin, y + 8);
    y += 8.5;
  });

  y += 12;
  // Analytical Sections
  const specAnalyses = [
    {
      title: 'RAM & Memory Capacity',
      desc: 'RAM exhibits a strict upward step curve across pricing segments. Budget models cluster around 3-4 GB, Mid-Range standards solidify at 6-8 GB, and Premium flagships command 12-16 GB for heavy multitasking and local on-device AI workloads.',
    },
    {
      title: 'Storage Capacity Trends',
      desc: 'Internal flash storage has shifted upward industry-wide. 64 GB remains in entry budget models, while 128 GB is the standard baseline for mid-range phones. Premium devices universally feature 256 GB or 512 GB UFS configurations.',
    },
    {
      title: 'Battery Capacity vs Physical Form',
      desc: 'Interestingly, battery capacity peaks in Mid-Range and Upper Mid-Range models (frequently 5000 to 6000 mAh), whereas Premium flagships balance 4400-5000 mAh batteries to maintain slim profiles, wireless coils, and high-density periscope cameras.',
    },
    {
      title: 'Camera Megapixel vs Processing Pipeline',
      desc: 'Primary camera resolutions range from 13 MP up to 200 MP sensors. High-megapixel binned sensors (108-200 MP) appear in both upper mid-range and premium tiers, while premium flagships invest heavily in larger physical sensor dies and secondary zoom telephotos.',
    },
    {
      title: 'Silicon & Clock Frequencies',
      desc: 'Processor clock speeds systematically scale from 1.6-2.0 GHz quad/octa-core budget silicon to 3.2-3.8 GHz flagship architectures featuring high-performance prime cores and specialized neural processing engines.',
    },
  ];

  specAnalyses.forEach(sec => {
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9.5);
    doc.setTextColor(30, 41, 59);
    doc.text(sec.title, margin, y);
    y += 4.5;

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8.5);
    doc.setTextColor(71, 85, 105);
    doc.text(sec.desc, margin, y, { maxWidth: contentWidth });
    y += 14;
  });

  addFooter(2);

  // ==========================================
  // PAGE 3: Prediction Record
  // ==========================================
  doc.addPage();
  addHeader('Mobile Phone Price Predictor Record', 'Page 3 — Entered Specifications & ML Model Inference', 3);

  y = 42;
  if (lastPrediction) {
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(12);
    doc.setTextColor(30, 41, 59);
    doc.text('Latest Prediction Assessment', margin, y);

    y += 8;
    // Prediction Banner
    doc.setFillColor(248, 250, 252);
    doc.setDrawColor(203, 213, 225);
    doc.roundedRect(margin, y, contentWidth, 38, 2, 2, 'FD');

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9);
    doc.setTextColor(100, 116, 139);
    doc.text('PREDICTED PRICE TIER', margin + 6, y + 10);
    doc.text(`Classifier Model: ${lastPrediction.modelUsed}`, margin + 110, y + 10);

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(18);
    doc.setTextColor(15, 23, 42);
    doc.text(lastPrediction.categoryName, margin + 6, y + 21);

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.setTextColor(16, 185, 129); // emerald
    doc.text(`Confidence: ${(lastPrediction.confidence * 100).toFixed(1)}%`, margin + 110, y + 21);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8.5);
    doc.setTextColor(100, 116, 139);
    doc.text(`Class Code: ${lastPrediction.predictedCategory} | Timestamp: ${lastPrediction.timestamp}`, margin + 6, y + 30);

    y += 46;
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.setTextColor(30, 41, 59);
    doc.text('Model Class Probability Distribution', margin, y);

    y += 6;
    cats.forEach(c => {
      const prob = lastPrediction.probabilities[c] || 0;
      const pct = (prob * 100).toFixed(1);
      const isWinner = c === lastPrediction.predictedCategory;

      doc.setFont('helvetica', isWinner ? 'bold' : 'normal');
      doc.setFontSize(8.5);
      doc.setTextColor(isWinner ? 15 : 71, isWinner ? 23 : 85, isWinner ? 42 : 105);
      doc.text(`${PRICE_CATEGORY_LABELS[c]} (Class ${c})`, margin, y + 4.5);
      doc.text(`${pct}%`, margin + 55, y + 4.5);

      // Draw progress bar
      doc.setFillColor(226, 232, 240);
      doc.rect(margin + 75, y + 1, 95, 4.5, 'F');
      if (prob > 0) {
        doc.setFillColor(isWinner ? 16 : 100, isWinner ? 185 : 116, isWinner ? 129 : 139);
        doc.rect(margin + 75, y + 1, 95 * prob, 4.5, 'F');
      }
      y += 8;
    });

    y += 10;
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.setTextColor(30, 41, 59);
    doc.text('Evaluated Hardware Specifications', margin, y);

    y += 6;
    const inputGrid = [
      { k: 'RAM', v: `${lastPrediction.input.ram} GB` },
      { k: 'Internal Storage', v: `${lastPrediction.input.internalStorage} GB` },
      { k: 'Battery Capacity', v: `${lastPrediction.input.batteryCapacity} mAh` },
      { k: 'Screen Size', v: `${lastPrediction.input.screenSize} inches` },
      { k: 'Primary Camera', v: `${lastPrediction.input.primaryCamera} MP` },
      { k: 'Front Camera', v: `${lastPrediction.input.frontCamera} MP` },
      { k: 'Processor Clock', v: `${lastPrediction.input.processorSpeed} GHz` },
      { k: 'Processor Cores', v: `${lastPrediction.input.processorCores} Cores` },
      { k: '5G Modem', v: lastPrediction.input.fiveG ? 'Supported' : 'None' },
      { k: 'Dual SIM', v: lastPrediction.input.dualSim ? 'Supported' : 'None' },
      { k: 'Fast Charging', v: lastPrediction.input.fastCharging ? 'Supported' : 'None' },
    ];

    doc.setFillColor(248, 250, 252);
    doc.rect(margin, y, contentWidth, 34, 'F');

    inputGrid.forEach((item, idx) => {
      const col = idx % 3;
      const row = Math.floor(idx / 3);
      const cx = margin + col * (contentWidth / 3) + 4;
      const cy = y + 7 + row * 8;

      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8);
      doc.setTextColor(100, 116, 139);
      doc.text(`${item.k}:`, cx, cy);

      doc.setFont('helvetica', 'bold');
      doc.setTextColor(30, 41, 59);
      doc.text(item.v, cx + 26, cy);
    });
  } else {
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(10);
    doc.setTextColor(100, 116, 139);
    doc.text(
      'No active custom prediction was recorded prior to exporting this report. The interactive Price Predictor section in the application enables testing custom mobile specifications at any time.',
      margin,
      y + 10,
      { maxWidth: contentWidth }
    );
  }

  addFooter(3);

  // ==========================================
  // PAGE 4: Model Performance
  // ==========================================
  doc.addPage();
  addHeader('Model Performance & Evaluation Metrics', 'Page 4 — Decision Tree vs. Random Forest Classification', 4);

  y = 42;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(30, 41, 59);
  doc.text('1. Overall Classification Performance (Test Partition)', margin, y);

  y += 6;
  doc.setFillColor(241, 245, 249);
  doc.rect(margin, y, contentWidth, 8, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.setTextColor(51, 65, 85);
  doc.text('Classifier Model', margin + 4, y + 5.5);
  doc.text('Accuracy', margin + 50, y + 5.5);
  doc.text('Precision (Wtd)', margin + 85, y + 5.5);
  doc.text('Recall (Wtd)', margin + 122, y + 5.5);
  doc.text('F1 Score (Wtd)', margin + 155, y + 5.5);

  const dt = trainingResult.decisionTree;
  const rf = trainingResult.randomForest;

  const modelsList = [dt, rf];
  y += 8;
  modelsList.forEach(m => {
    const isBest = m.name === trainingResult.bestModel;
    doc.setFont('helvetica', isBest ? 'bold' : 'normal');
    doc.setFontSize(8.5);
    doc.setTextColor(51, 65, 85);
    doc.text(`${m.name} ${isBest ? '(Best Model)' : ''}`, margin + 4, y + 5.5);
    doc.text(`${(m.accuracy * 100).toFixed(1)}%`, margin + 52, y + 5.5);
    doc.text(`${(m.precisionWeighted * 100).toFixed(1)}%`, margin + 88, y + 5.5);
    doc.text(`${(m.recallWeighted * 100).toFixed(1)}%`, margin + 125, y + 5.5);
    doc.text(`${(m.f1Weighted * 100).toFixed(1)}%`, margin + 158, y + 5.5);

    doc.setDrawColor(241, 245, 249);
    doc.line(margin, y + 8, pageWidth - margin, y + 8);
    y += 8.5;
  });

  y += 10;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(30, 41, 59);
  doc.text(`2. Confusion Matrix (${trainingResult.bestModel})`, margin, y);

  y += 6;
  const matrixSource = trainingResult.bestModel === 'Random Forest' ? rf : dt;
  doc.setFillColor(241, 245, 249);
  doc.rect(margin, y, contentWidth, 7, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(51, 65, 85);
  doc.text('Actual \\ Predicted', margin + 3, y + 5);
  doc.text('Budget (0)', margin + 48, y + 5);
  doc.text('Mid-Range (1)', margin + 82, y + 5);
  doc.text('Upper Mid (2)', margin + 118, y + 5);
  doc.text('Premium (3)', margin + 152, y + 5);

  y += 7;
  matrixSource.confusionMatrix.forEach(row => {
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8);
    doc.setTextColor(51, 65, 85);
    doc.text(row.actualLabel, margin + 3, y + 5);

    cats.forEach((predCat, pIdx) => {
      const val = row.predicted[predCat] || 0;
      const isDiagonal = row.actual === predCat;
      const xPos = margin + 55 + pIdx * 35;

      if (isDiagonal && val > 0) {
        doc.setFillColor(220, 252, 231); // green tint for correct
        doc.rect(xPos - 5, y + 1, 16, 6, 'F');
      }

      doc.setFont('helvetica', isDiagonal ? 'bold' : 'normal');
      doc.setTextColor(isDiagonal ? 22 : 100, isDiagonal ? 101 : 116, isDiagonal ? 52 : 139);
      doc.text(String(val), xPos, y + 5);
    });

    doc.setDrawColor(241, 245, 249);
    doc.line(margin, y + 7, pageWidth - margin, y + 7);
    y += 7.5;
  });

  y += 10;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(30, 41, 59);
  doc.text('3. Feature Importance Ranking', margin, y);

  y += 6;
  const topFeatures = rf.featureImportances.slice(0, 7);
  topFeatures.forEach((feat, idx) => {
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.setTextColor(51, 65, 85);
    doc.text(`${idx + 1}. ${feat.label}`, margin, y + 4);
    doc.text(`${feat.percentage}%`, margin + 65, y + 4);

    // bar
    doc.setFillColor(226, 232, 240);
    doc.rect(margin + 80, y + 1, 85, 3.8, 'F');
    doc.setFillColor(59, 130, 246);
    doc.rect(margin + 80, y + 1, Math.min(85, (feat.percentage / 100) * 85 * 3), 3.8, 'F');

    y += 6.5;
  });

  addFooter(4);

  // ==========================================
  // PAGE 5: Dynamic Insights
  // ==========================================
  doc.addPage();
  addHeader('Machine Learning Insights & Observations', 'Page 5 — Executive Synthesis & Strategic Findings', 5);

  y = 42;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(30, 41, 59);
  doc.text('1. Dynamic Dataset & Model Observations', margin, y);

  y += 8;
  insights.forEach(item => {
    doc.setFillColor(248, 250, 252);
    doc.setDrawColor(226, 232, 240);
    doc.roundedRect(margin, y, contentWidth, 20, 2, 2, 'FD');

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9);
    doc.setTextColor(15, 23, 42);
    doc.text(item.title, margin + 5, y + 6);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7.5);
    doc.setTextColor(59, 130, 246);
    doc.text(`[${item.badge}]`, pageWidth - margin - 35, y + 6);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8.2);
    doc.setTextColor(71, 85, 105);
    doc.text(item.description, margin + 5, y + 12, { maxWidth: contentWidth - 10 });

    y += 24;
  });

  y += 6;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(30, 41, 59);
  doc.text('2. Methodological Summary & Boundary Conditions', margin, y);

  y += 6;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(71, 85, 105);
  doc.text(
    '1. Classification vs Regression: This system strictly classifies devices into categorical tiers (Budget, Mid-Range, Upper Mid-Range, Premium) rather than predicting raw currency exchange prices.\n' +
    '2. Target Leakage Prevention: Engineered features (Memory Score, Camera Score, Processing Score) are calculated purely from hardware attributes without reference to price category.\n' +
    '3. Browser-Native Computation: Dataset parsing, CART Decision Tree training, Random Forest ensemble bagging, and inference are executed locally without transmitting client data to external servers.',
    margin,
    y,
    { maxWidth: contentWidth }
  );

  addFooter(5);

  // Save the PDF
  doc.save('mobile-phone-price-prediction-report.pdf');
}
